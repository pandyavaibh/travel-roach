import type { Config } from 'tailwindcss';

export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        ink:    { DEFAULT: '#17160F', 2: '#3B372B', 3: '#4C4739' },
        paper:  '#F4F1EA',
        rule:   { DEFAULT: '#E0DACB', 2: '#EFEAE0', 3: '#C9C2B8', dark: '#2A2824' },
        muted:  { DEFAULT: '#8C8677', 2: '#6E6858', 3: '#B4AE9E' },
        orange: { DEFAULT: '#E85D04', deep: '#A0451F' },
        sand:   { DEFAULT: '#FBEAD8', rule: '#F3D9BE' },
        // Trust states. Verified badges are the revenue signal, so they stay
        // visually separate from the orange call-to-action.
        trust:  { DEFAULT: '#15803D', soft: '#DCFCE7', ink: '#14532D' },
        // Full-width dark blocks.
        night:  { DEFAULT: '#12110D', 2: '#1C1A15', line: '#2A2824', soft: '#8C8677' },
      },
      fontFamily: {
        serif: ['var(--font-serif)', 'Georgia', 'serif'],
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
      },
      borderRadius: { card: '8px', hero: '16px' },
      maxWidth: { shell: '1440px' },
      boxShadow: {
        menu: '0 24px 48px -24px rgba(18,17,13,.22)',
        card: '0 1px 2px rgba(18,17,13,.04)',
        lift: '0 8px 24px -12px rgba(18,17,13,.14)',
      },
    },
  },
  plugins: [],
} satisfies Config;

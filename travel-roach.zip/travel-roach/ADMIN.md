# The admin and owner portal

Everything is built: editorial, the directory, owner self-service, traveller reviews, and analytics.

---

## Setup

You need a Postgres database. [Neon](https://neon.tech)'s free tier fits this site — create a project and copy the **pooled** connection string. `database/README.md` covers alternatives.

```bash
cp .env.example .env
```

| Variable | Where it comes from |
|---|---|
| `DATABASE_URL` | the pooled Postgres string |
| `SESSION_SECRET` | `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `NEXT_PUBLIC_SITE_URL` | your domain, or `http://localhost:3000` in dev |
| `BREVO_API_KEY` | brevo.com → SMTP & API. Optional in dev. |
| `CRON_SECRET` | any random string — protects the monthly housekeeping route |

Use the **pooled** string, not the direct one — a serverless app opens and closes connections constantly and will exhaust direct limits.

```bash
npm install
npm run db:setup      # tables, 35 states, Ahmedabad content
npm run db:admin      # your admin account
npm run dev
```

Three entrances:

| URL | Who |
|---|---|
| `/` | Travellers |
| `/admin/login` | You and your editors |
| `/portal/login` | Business owners |

**Coming from stage 1?** Run the one migration that adds per-city indexing:

```bash
psql "$DATABASE_URL" -f database/002-city-noindex.sql
```

Stage 3 needs no migration — it uses tables already in the dump.

---

## The owner portal

### How an owner gets in

Open signup at `/portal/signup`, then email verification, then a claim. The claim is the real gate, not the signup.

`domainMatches()` in `src/lib/auth.ts` compares the signup email domain against the listing's website. `booking@houseofmg.com` claiming The House of MG **auto-approves** — they own the domain, so they own the business. Anything else queues at `/admin/claims` for you.

Free providers — Gmail, Yahoo, Outlook, Rediffmail, iCloud, Proton — are explicitly excluded. Without that the check would be meaningless, since anyone can make a Gmail address.

An owner can hold several listings. One hotel group, one login.

### The dashboard

Six cards, equal weight, as you asked: enquiries received, profile views this month, photos, prices and rooms, reviews to reply to, verification status.

Each links to a focused screen:

| Screen | What an owner does |
|---|---|
| **Details** | Description, contact, address, hours, price from |
| **Photos** | Upload, reorder, delete, set the hero. Capped at 50. |
| **Rooms / menu / packages** | The same table serves all three — rooms for hotels, menu sections for restaurants, tour packages for agents |
| **Reviews** | Read and reply. They cannot delete. |
| **Enquiries** | Mark read or replied |

Edits go live immediately, no approval queue — that was your call. Two things they cannot touch: the verified badge and their position in the listing order.

### What owners cannot do

Change their rating, delete a review, or buy a better position. The directory sorts by rating and response time. The listing page says so in writing, and the code has no mechanism to override it.

---

## Traveller reviews

Anyone email-verified can review. Anyone with an **enquiry on record for that listing** gets the verified-booking mark automatically — checked at submission, not self-declared.

Reviews publish immediately, as you chose. The brakes:

- Email verification required
- One review per person per listing, enforced by a unique index rather than application code
- Up to 10 photos, resized to WebP on upload
- Owners can reply but never delete
- Anyone can report; reported reviews surface at `/admin/reviews?status=reported`

Publishing a review recalculates the listing's cached rating and review count in the same request, so cards and profiles never aggregate on read.

---

## Admin screens

| Screen | What it does |
|---|---|
| **Dashboard** | Counts that need action, each linking to its queue |
| **Posts** | The Tiptap editor. Draft and publish. |
| **Attractions** | Visitor details, history, tips, coordinates |
| **Festivals** | Dates, venue, ticketing, what happens |
| **Itineraries** | Days, route, inclusions, a repeatable day-by-day plan |
| **Cities** | Publish/hide, and allow-indexing/noindex, per city |
| **Listings** | Verify, unverify, publish, hide, release an owner |
| **Claims** | Approve or reject, with the domain-match result shown |
| **Reviews** | Hide, restore, or clear a report |
| **Enquiries** | Every enquiry across the site |
| **Media** | The whole library |
| **Users** | Accounts and roles |

Attractions, festivals and itineraries share one set of screens at `/admin/records/[kind]` — they differ only in their fields, so one definition table in `src/lib/records.ts` drives all three rather than three near-identical copies of the posts screens.

### Verifying a listing

`/admin/listings` → Verify. That sets `verified`, stamps `verified_at`, and the green badge appears immediately.

The badge means you checked a document — an IATA accreditation, a state tourism registration, an ASI guide licence, a trading licence. It is not a quality judgement, and `list-your-business` says so.

**This is the revenue mechanism.** Businesses pay to be verified and to manage their own listing. They do not pay for position, because the moment position is for sale the badge stops meaning anything.

---

## Roles

| Role | Can do |
|---|---|
| **admin** | Everything, including users and roles |
| **editor** | Write, publish, manage cities, listings, claims, reviews, media |
| **owner** | Their own listings only |
| **traveller** | Review and upload photos, once email is confirmed |

You cannot demote or delete your own admin account — that is the lockout guard.

Ownership is checked per listing on every portal action, not once at login. An owner editing `?id=7` when they own listing 4 gets a redirect, not an error.

---

## Two content sources

The public site reads Postgres first, files second:

- **A city with published posts serves real content.** Ahmedabad, out of the box.
- **A city without them still renders** from generated scaffolding — no 404s, state hubs stay populated — but carries `noindex` until a person writes for it.
- **No database at all still works.** A missing or unreachable `DATABASE_URL` degrades to files rather than a 500.

Listings are different: **only real database listings show reviews and accept enquiries.** A file-backed listing renders its details but has no review form, because there is no row to attach a review to.

`src/lib/data.ts` holds all of it. Every function returns `{ data, source, noindex }`.

---

## Email

Brevo. Verification, password resets, claim decisions and enquiry notifications all go through it.

**Without `BREVO_API_KEY`, emails log to the server console.** Development needs no setup and nothing fails silently — but note that email verification is required to review, so in dev you read the link out of the console.

For production deliverability, add Brevo's SPF and DKIM records to your DNS. Without them, password resets land in spam.

---

## Uploads

`public/uploads/YYYY/MM/`, resized to 1800px wide, converted to WebP, with a 400px square thumbnail. Originals are discarded.

Caps: **50 per listing for owners, 10 per review for travellers.**

If your host rebuilds the container on deploy, `public/uploads` can be wiped. Check for persistent storage. If there is none, move to Cloudflare R2 or Supabase Storage — `src/lib/upload.ts` is the only file that changes.

---

## Still open

**Analytics is live but new.** Page views are counted from the browser after hydration (`TrackView` → `/api/view`), rolled into one row per path per day. The homepage switches from editorial picks to real ranking once four or more cities have traffic — ranking three page views as "most-read" would be worse than honest editorial. Owner profile views come from the same source.

Two housekeeping jobs run at `/api/cron/monthly`: zeroing the owner view counters and trimming rows over 90 days. Point a scheduler at it on the first of the month and set `CRON_SECRET`, or the route refuses to run.

**Photography.** Every image is still a placeholder — the one remaining visual gap.

**Listings still come from files** for their core details. Reviews, ratings, photos and owner edits are live; the name, blurb and tags come from `src/content/listings.ts` until a listing is imported into Postgres. The Ahmedabad 29 are imported.

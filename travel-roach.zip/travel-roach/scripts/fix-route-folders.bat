@echo off
REM Windows version. Run from the project root:  scripts\fix-route-folders.bat
cd /d "%~dp0..\src\app"
if exist "-state-\-city-\-section-\-slug-" ren "-state-\-city-\-section-\-slug-" "[slug]"
if exist "-state-\-city-\-section-" ren "-state-\-city-\-section-" "[section]"
if exist "-state-\-city-" ren "-state-\-city-" "[city]"
if exist "-state-" ren "-state-" "[state]"
if exist "admin\posts\-id-" ren "admin\posts\-id-" "[id]"
if exist "admin\records\-kind-\-id-" ren "admin\records\-kind-\-id-" "[id]"
if exist "admin\records\-kind-" ren "admin\records\-kind-" "[kind]"
if exist "portal\-id-" ren "portal\-id-" "[id]"
echo Done. Now run: npm install ^&^& npm run db:setup
pause

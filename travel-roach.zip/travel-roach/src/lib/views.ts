import 'server-only';
import { sql } from 'drizzle-orm';

/**
 * Page-view counting. One row per path per day, incremented with an upsert, so
 * a busy page costs one statement rather than a growing table of events.
 *
 * Called from a route handler rather than a server component: components are
 * cached and would under-count badly.
 */
export async function recordView(path: string, listingId?: number) {
  if (!process.env.DATABASE_URL) return;
  try {
    const { db, pageViews, listings } = await import('@/db');
    const day = new Date().toISOString().slice(0, 10);

    await db.insert(pageViews)
      .values({ path, day, hits: 1, listingId: listingId ?? null })
      .onConflictDoUpdate({
        target: [pageViews.path, pageViews.day],
        set: { hits: sql`${pageViews.hits} + 1` },
      });

    // Denormalised so the owner dashboard reads one column, not an aggregate.
    if (listingId) {
      await db.update(listings)
        .set({ viewsThisMonth: sql`${listings.viewsThisMonth} + 1` })
        .where(sql`${listings.id} = ${listingId}`);
    }
  } catch (err) {
    // Analytics must never break a page render.
    console.error('[views] failed:', err);
  }
}

export type PopularCity = {
  stateSlug: string; citySlug: string; hits: number;
  move: 'up' | 'down' | 'flat'; delta: number;
};

/**
 * Cities by hits in the last 24 hours, with movement against the previous 24.
 * Falls back to an empty array — the homepage keeps its curated list until
 * there is enough traffic to rank honestly.
 */
export async function popularCities(limit = 8): Promise<PopularCity[]> {
  if (!process.env.DATABASE_URL) return [];
  try {
    const { db } = await import('@/db');
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 864e5).toISOString().slice(0, 10);

    // Paths look like /gujarat/ahmedabad or /gujarat/ahmedabad/food.
    // Group on the first two segments to roll a city's pages together.
    const rows = await db.execute<{ state: string; city: string; hits: number; prev: number }>(sql`
      WITH parts AS (
        SELECT
          split_part(path, '/', 2) AS state,
          split_part(path, '/', 3) AS city,
          day, hits
        FROM page_views
        WHERE day IN (${today}, ${yesterday})
          AND split_part(path, '/', 3) <> ''
      )
      SELECT
        state,
        city,
        COALESCE(SUM(hits) FILTER (WHERE day = ${today}), 0)::int     AS hits,
        COALESCE(SUM(hits) FILTER (WHERE day = ${yesterday}), 0)::int AS prev
      FROM parts
      GROUP BY state, city
      HAVING COALESCE(SUM(hits) FILTER (WHERE day = ${today}), 0) > 0
      ORDER BY hits DESC
      LIMIT ${limit}
    `);

    return (rows as unknown as any[]).map((r) => {
      const delta = Number(r.hits) - Number(r.prev);
      return {
        stateSlug: r.state,
        citySlug: r.city,
        hits: Number(r.hits),
        move: delta > 0 ? 'up' : delta < 0 ? 'down' : 'flat',
        delta: Math.abs(delta),
      } as PopularCity;
    });
  } catch (err) {
    console.error('[views] popularCities failed:', err);
    return [];
  }
}

/** Trims rows older than 90 days. Call from a cron if the table grows. */
export async function pruneViews(days = 90) {
  if (!process.env.DATABASE_URL) return;
  const { db, pageViews } = await import('@/db');
  const cutoff = new Date(Date.now() - days * 864e5).toISOString().slice(0, 10);
  await db.delete(pageViews).where(sql`${pageViews.day} < ${cutoff}`);
}

/**
 * Resets the owner-dashboard counter. Call on the first of the month — the
 * cron route at /api/cron/monthly does it if you point a scheduler there.
 */
export async function resetMonthlyViews() {
  if (!process.env.DATABASE_URL) return;
  const { db, listings } = await import('@/db');
  await db.update(listings).set({ viewsThisMonth: 0 });
}

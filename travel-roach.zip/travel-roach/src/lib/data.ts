import 'server-only';
import { and, desc, eq } from 'drizzle-orm';
import { unstable_cache } from 'next/cache';

import { STATE_BY_SLUG, type State } from '@/content/states';
import { CITIES, CITY_BY_KEY, type City } from '@/content/cities';
import { articlesFor, articleBySlug, type Article } from '@/content/articles';
import { attractionsFor, attractionBySlug, type Attraction } from '@/content/places';
import { eventsFor, eventBySlug, eventsForState, type Event } from '@/content/events';
import { packagesFor, type Pkg } from '@/content/packages';

/**
 * Reads content from Postgres when it is there, and from src/content/*.ts when
 * it is not.
 *
 * Two reasons for the fallback rather than a hard cutover:
 *
 *  1. The site boots and renders with no database at all. A missing or
 *     unreachable DATABASE_URL degrades to files instead of a 500.
 *  2. Only cities someone has actually written for exist in the database. The
 *     other 85 still render from generated scaffolding, marked noindex, until
 *     an editor replaces them.
 *
 * Every function returns the same shape whichever source answered, plus a
 * `source` field so pages can set robots metadata accordingly.
 */

export type Source = 'db' | 'file';
export type Sourced<T> = { data: T; source: Source; noindex: boolean };

const HAS_DB = !!process.env.DATABASE_URL;

/** Lazy import: pulling the driver in at module scope would break file-only mode. */
async function database() {
  if (!HAS_DB) return null;
  try {
    const mod = await import('@/db');
    return mod;
  } catch (err) {
    console.error('[data] database import failed, using files:', err);
    return null;
  }
}

/** Swallows connection errors so one bad query cannot take a page down. */
async function attempt<T>(label: string, fn: () => Promise<T>): Promise<T | null> {
  try {
    return await fn();
  } catch (err) {
    console.error(`[data] ${label} failed, using files:`, err);
    return null;
  }
}

/* ---------------- Geography ---------------- */

export type CityRecord = City & { id?: number; published?: boolean };

export async function getState(slug: string): Promise<Sourced<State> | null> {
  const file = STATE_BY_SLUG.get(slug);
  const db = await database();

  if (db) {
    const row = await attempt('getState', async () => {
      const [r] = await db.db.select().from(db.states)
        .where(and(eq(db.states.slug, slug), eq(db.states.published, true)))
        .limit(1);
      return r ?? null;
    });
    if (row) {
      return {
        source: 'db',
        noindex: false,
        data: {
          slug: row.slug,
          name: row.name,
          kind: row.kind,
          region: row.region,
          tagline: row.tagline ?? '',
          bestSeason: row.bestSeason ?? '',
          daysNeeded: row.daysNeeded ?? '',
          dailyBudget: row.dailyBudget ?? '',
          airports: row.airports ?? '',
          intro: splitHtml(row.intro),
          quote: row.quote ?? '',
          quoteBy: row.quoteBy ?? '',
        },
      };
    }
  }

  return file ? { data: file, source: 'file', noindex: false } : null;
}

/**
 * Cities in the database carry the noindex switch. Cities that exist only as
 * generated scaffolding are always noindex — nobody has checked them.
 */
export async function getCity(stateSlug: string, citySlug: string): Promise<Sourced<{ city: CityRecord; state: State }> | null> {
  const db = await database();

  if (db) {
    const row = await attempt('getCity', async () => {
      const [r] = await db.db
        .select({ city: db.cities, state: db.states })
        .from(db.cities)
        .innerJoin(db.states, eq(db.cities.stateId, db.states.id))
        .where(and(
          eq(db.states.slug, stateSlug),
          eq(db.cities.slug, citySlug),
          eq(db.cities.published, true),
        ))
        .limit(1);
      return r ?? null;
    });

    if (row) {
      const fileState = STATE_BY_SLUG.get(stateSlug);
      return {
        source: 'db',
        noindex: !!row.city.noindex,
        data: {
          city: {
            id: row.city.id,
            slug: row.city.slug,
            stateSlug,
            name: row.city.name,
            tagline: row.city.tagline ?? '',
            intro: row.city.intro ?? '',
            bestSeason: row.city.bestSeason ?? '',
            daysNeeded: row.city.daysNeeded ?? '',
            dailyBudget: row.city.dailyBudget ?? '',
            nearestAirport: row.city.nearestAirport ?? '',
            published: true,
          },
          state: fileState ?? {
            slug: row.state.slug, name: row.state.name, kind: row.state.kind,
            region: row.state.region, tagline: row.state.tagline ?? '',
            bestSeason: row.state.bestSeason ?? '', daysNeeded: row.state.daysNeeded ?? '',
            dailyBudget: row.state.dailyBudget ?? '', airports: row.state.airports ?? '',
            intro: splitHtml(row.state.intro), quote: row.state.quote ?? '',
            quoteBy: row.state.quoteBy ?? '',
          },
        },
      };
    }
  }

  const city = CITY_BY_KEY.get(stateSlug + '/' + citySlug);
  const state = STATE_BY_SLUG.get(stateSlug);
  if (!city || !state) return null;
  // Generated scaffolding: serve it, but keep it out of the index.
  return { data: { city, state }, source: 'file', noindex: true };
}

/** State hubs list only cities that are live. Falls back to the full file list. */
export async function getCitiesOf(stateSlug: string): Promise<Sourced<CityRecord[]>> {
  const db = await database();

  if (db) {
    const rows = await attempt('getCitiesOf', async () =>
      db.db.select({ city: db.cities })
        .from(db.cities)
        .innerJoin(db.states, eq(db.cities.stateId, db.states.id))
        .where(and(eq(db.states.slug, stateSlug), eq(db.cities.published, true)))
        .orderBy(db.cities.name));

    if (rows && rows.length) {
      return {
        source: 'db',
        noindex: false,
        data: rows.map(({ city }) => ({
          id: city.id, slug: city.slug, stateSlug, name: city.name,
          tagline: city.tagline ?? '', intro: city.intro ?? '',
          bestSeason: city.bestSeason ?? '', daysNeeded: city.daysNeeded ?? '',
          dailyBudget: city.dailyBudget ?? '', nearestAirport: city.nearestAirport ?? '',
          published: true,
        })),
      };
    }
  }

  return {
    data: CITIES.filter((c) => c.stateSlug === stateSlug),
    source: 'file',
    noindex: true,
  };
}

/* ---------------- Posts ---------------- */

function splitHtml(html: string | null): string[] {
  if (!html) return [];
  const paras = html.match(/<p>([\s\S]*?)<\/p>/g);
  if (!paras) return [html];
  return paras.map((p) => p.replace(/<\/?p>/g, '').trim()).filter(Boolean);
}

const AUTHOR_FALLBACK = 'Travel Roach';

export async function getPosts(stateSlug: string, citySlug: string, section: string): Promise<Sourced<Article[]>> {
  const db = await database();

  if (db) {
    const rows = await attempt('getPosts', async () =>
      db.db
        .select({ post: db.posts, author: db.users.name })
        .from(db.posts)
        .innerJoin(db.cities, eq(db.posts.cityId, db.cities.id))
        .innerJoin(db.states, eq(db.cities.stateId, db.states.id))
        .leftJoin(db.users, eq(db.posts.authorId, db.users.id))
        .where(and(
          eq(db.states.slug, stateSlug),
          eq(db.cities.slug, citySlug),
          eq(db.posts.section, section as 'things-to-do'),
          eq(db.posts.status, 'published'),
        ))
        .orderBy(desc(db.posts.featured), desc(db.posts.publishedAt)));

    if (rows && rows.length) {
      return {
        source: 'db',
        noindex: false,
        data: rows.map(({ post, author }) => toArticle(post, author, stateSlug, citySlug)),
      };
    }
  }

  return { data: articlesFor(stateSlug, citySlug, section), source: 'file', noindex: true };
}

export async function getPost(stateSlug: string, citySlug: string, section: string, slug: string): Promise<Sourced<Article> | null> {
  const db = await database();

  if (db) {
    const row = await attempt('getPost', async () => {
      const [r] = await db.db
        .select({ post: db.posts, author: db.users.name })
        .from(db.posts)
        .innerJoin(db.cities, eq(db.posts.cityId, db.cities.id))
        .innerJoin(db.states, eq(db.cities.stateId, db.states.id))
        .leftJoin(db.users, eq(db.posts.authorId, db.users.id))
        .where(and(
          eq(db.posts.slug, slug),
          eq(db.states.slug, stateSlug),
          eq(db.cities.slug, citySlug),
          eq(db.posts.status, 'published'),
        ))
        .limit(1);
      return r ?? null;
    });

    if (row) {
      return {
        source: 'db',
        noindex: false,
        data: toArticle(row.post, row.author, stateSlug, citySlug),
      };
    }
  }

  const file = articleBySlug(stateSlug, citySlug, section, slug);
  return file ? { data: file, source: 'file', noindex: true } : null;
}

type PostRow = {
  slug: string; section: string; kicker: string | null; title: string; dek: string | null;
  bodyHtml: string | null; takeaways: string[] | null; readingMinutes: number | null;
  featured: boolean | null; publishedAt: Date | null;
};

function toArticle(post: PostRow, author: string | null, stateSlug: string, citySlug: string): Article {
  return {
    slug: post.slug,
    stateSlug,
    citySlug,
    section: post.section,
    kicker: post.kicker ?? '',
    title: post.title,
    dek: post.dek ?? '',
    author: author ?? AUTHOR_FALLBACK,
    minutes: post.readingMinutes ?? 5,
    featured: !!post.featured,
    published: post.publishedAt ? post.publishedAt.toISOString().slice(0, 10) : '',
    body: splitHtml(post.bodyHtml),
    takeaways: post.takeaways ?? [],
  };
}

/* ---------------- Route params ---------------- */

/**
 * Pre-render published database cities plus every file city, so no URL that
 * worked before this change starts 404ing.
 */
export const publishedCityParams = unstable_cache(
  async () => {
    const db = await database();
    const fromFiles = CITIES.map((c) => ({ state: c.stateSlug, city: c.slug }));
    if (!db) return fromFiles;

    const rows = await attempt('publishedCityParams', async () =>
      db.db.select({ city: db.cities.slug, state: db.states.slug })
        .from(db.cities)
        .innerJoin(db.states, eq(db.cities.stateId, db.states.id))
        .where(eq(db.cities.published, true)));

    if (!rows) return fromFiles;
    const seen = new Set(rows.map((r) => r.state + '/' + r.city));
    return [...rows, ...fromFiles.filter((f) => !seen.has(f.state + '/' + f.city))];
  },
  ['published-city-params'],
  { revalidate: 3600 },
);

/** robots metadata for a page whose content came from generated scaffolding. */
export const robotsFor = (noindex: boolean) =>
  noindex ? { robots: { index: false, follow: true } } : {};

/* ---------- Attractions, festivals, itineraries ---------- */

/**
 * These three read the database first and fall back to generated files, same
 * as posts. Shapes are mapped to the file types so the page components did not
 * have to change.
 */

export async function getAttractions(stateSlug: string, citySlug: string): Promise<Sourced<Attraction[]>> {
  const mod = await database();

  if (mod) {
    const rows = await attempt('getAttractions', async () => {
      const { db, attractions, cities, states } = mod;
      return db.select().from(attractions)
        .innerJoin(cities, eq(attractions.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .where(and(
          eq(states.slug, stateSlug),
          eq(cities.slug, citySlug),
          eq(attractions.status, 'published'),
        ))
        .orderBy(attractions.sortRank);
    });

    if (rows && rows.length) {
      return {
        source: 'db',
        noindex: false,
        data: rows.map((r) => toAttraction(r.attractions, stateSlug, citySlug)),
      };
    }
  }

  return { data: attractionsFor(stateSlug, citySlug), source: 'file', noindex: true };
}

export async function getAttraction(stateSlug: string, citySlug: string, slug: string): Promise<Sourced<Attraction> | null> {
  const mod = await database();

  if (mod) {
    const row = await attempt('getAttraction', async () => {
      const { db, attractions, cities, states } = mod;
      const [r] = await db.select().from(attractions)
        .innerJoin(cities, eq(attractions.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .where(and(
          eq(attractions.slug, slug),
          eq(states.slug, stateSlug),
          eq(cities.slug, citySlug),
          eq(attractions.status, 'published'),
        ))
        .limit(1);
      return r ?? null;
    });

    if (row) {
      return { data: toAttraction(row.attractions, stateSlug, citySlug), source: 'db', noindex: false };
    }
  }

  const file = attractionBySlug(stateSlug, citySlug, slug);
  return file ? { data: file, source: 'file', noindex: true } : null;
}

export async function getEvents(stateSlug: string, citySlug: string): Promise<Sourced<Event[]>> {
  const mod = await database();

  if (mod) {
    const rows = await attempt('getEvents', async () => {
      const { db, events, cities, states } = mod;
      return db.select().from(events)
        .innerJoin(cities, eq(events.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .where(and(
          eq(states.slug, stateSlug),
          eq(cities.slug, citySlug),
          eq(events.status, 'published'),
        ))
        .orderBy(events.startsOn);
    });

    if (rows && rows.length) {
      return { source: 'db', noindex: false, data: rows.map((r) => toEvent(r.events, stateSlug, citySlug)) };
    }
  }

  return { data: eventsFor(stateSlug, citySlug), source: 'file', noindex: true };
}

export async function getEvent(stateSlug: string, citySlug: string, slug: string): Promise<Sourced<Event> | null> {
  const list = await getEvents(stateSlug, citySlug);
  const hit = list.data.find((e) => e.slug === slug);
  if (hit) return { data: hit, source: list.source, noindex: list.noindex };

  const file = eventBySlug(stateSlug, citySlug, slug);
  return file ? { data: file, source: 'file', noindex: true } : null;
}

export async function getPackages(stateSlug: string, citySlug: string): Promise<Sourced<Pkg[]>> {
  const mod = await database();

  if (mod) {
    const rows = await attempt('getPackages', async () => {
      const { db, packages, cities, states } = mod;
      return db.select().from(packages)
        .innerJoin(cities, eq(packages.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .where(and(
          eq(states.slug, stateSlug),
          eq(cities.slug, citySlug),
          eq(packages.status, 'published'),
        ))
        .orderBy(packages.days, packages.sortOrder);
    });

    if (rows && rows.length) {
      return { source: 'db', noindex: false, data: rows.map((r) => toPkg(r.packages, stateSlug, citySlug)) };
    }
  }

  return { data: packagesFor(stateSlug, citySlug), source: 'file', noindex: true };
}

export async function getPackage(stateSlug: string, citySlug: string, slug: string): Promise<Sourced<Pkg> | null> {
  const list = await getPackages(stateSlug, citySlug);
  const hit = list.data.find((p) => p.slug === slug);
  if (hit) return { data: hit, source: list.source, noindex: list.noindex };

  const file = packagesFor(stateSlug, citySlug).find((p) => p.slug === slug);
  return file ? { data: file, source: 'file', noindex: true } : null;
}

/**
 * The state hub's festival calendar. Real events replace generated ones per
 * city, so a state can be part-written without the calendar going half-empty.
 */
export async function getEventsForState(stateSlug: string): Promise<Event[]> {
  const mod = await database();
  const fromFiles = eventsForState(stateSlug);

  if (!mod) return fromFiles;

  const rows = await attempt('getEventsForState', async () => {
    const { db, events, cities, states } = mod;
    return db
      .select({ event: events, citySlug: cities.slug })
      .from(events)
      .innerJoin(cities, eq(events.cityId, cities.id))
      .innerJoin(states, eq(cities.stateId, states.id))
      .where(and(eq(states.slug, stateSlug), eq(events.status, 'published')));
  });

  if (!rows || !rows.length) return fromFiles;

  // A city with real events keeps only those; the rest stay on scaffolding.
  const written = new Set(rows.map((r) => r.citySlug));
  const live = rows.map((r) => toEvent(r.event, stateSlug, r.citySlug));

  return [...live, ...fromFiles.filter((e) => !written.has(e.citySlug))]
    .sort((a, b) => a.startsOn.localeCompare(b.startsOn));
}

/* Row-to-file-shape mappers. The page components were written against the
   generated types, so the database rows are mapped rather than the reverse. */

function toAttraction(r: Record<string, any>, stateSlug: string, citySlug: string): Attraction {
  return {
    slug: r.slug, stateSlug, citySlug,
    name: r.name, category: r.category ?? 'Place',
    summary: r.summary ?? '',
    rank: r.sortRank ?? 99,
    timings: r.timings ?? 'Check locally',
    entryFee: r.entryFee ?? '—',
    timeNeeded: r.timeNeeded ?? '1 – 2 hours',
    bestTime: r.bestTime ?? 'Morning',
    closedOn: r.closedOn ?? 'Open daily',
    photography: r.photography ?? 'Allowed',
    nearestStation: r.nearestStation ?? '—',
    accessibility: r.accessibility ?? '—',
    history: splitHtml(r.historyHtml),
    tips: Array.isArray(r.tips) ? r.tips : [],
    lat: r.lat ? Number(r.lat) : 0,
    lng: r.lng ? Number(r.lng) : 0,
  };
}

function toEvent(r: Record<string, any>, stateSlug: string, citySlug: string): Event {
  return {
    slug: r.slug, stateSlug, citySlug,
    name: r.name,
    startsOn: r.startsOn,
    endsOn: r.endsOn ?? null,
    venue: r.venue ?? '',
    ticketed: !!r.ticketed,
    priceFrom: r.priceFrom ?? null,
    note: r.note ?? '',
    bookAhead: r.bookAhead ?? null,
    season: r.season ?? 'Year round',
  };
}

function toPkg(r: Record<string, any>, stateSlug: string, citySlug: string): Pkg {
  return {
    slug: r.slug, stateSlug, citySlug,
    name: r.name,
    days: r.days,
    route: r.route ?? '',
    note: r.note ?? '',
    inclusions: Array.isArray(r.inclusions) ? r.inclusions : [],
    priceFrom: r.priceFrom ?? 0,
    sellers: 0,
    dayPlan: Array.isArray(r.dayPlan) ? r.dayPlan : [],
  };
}

/* ---------- Listings: reviews and owner edits are always live ---------- */

export type LiveReview = {
  id: number; author: string; rating: number; body: string | null;
  tripLabel: string | null; verifiedBooking: boolean;
  ownerReply: string | null; createdAt: Date | null;
  photos: { path: string; thumbPath: string | null }[];
};

/**
 * Resolves a file-backed listing slug to its database row, so reviews, the
 * cached rating and any owner edits come from Postgres while the rest of the
 * listing still comes from src/content. Null when not yet imported.
 */
export async function getListingLive(slug: string) {
  const mod = await database();
  if (!mod) return null;

  return attempt('getListingLive', async () => {
    const { db, listings, reviews, users, media } = mod;

    const [l] = await db
      .select({
        id: listings.id, heroMediaId: listings.heroMediaId,
        rating: listings.ratingCached, count: listings.reviewCountCached,
        verified: listings.verified, verifiedAt: listings.verifiedAt,
        registration: listings.registration,
        blurb: listings.blurb, aboutHtml: listings.aboutHtml,
        phone: listings.phone, whatsapp: listings.whatsapp, website: listings.website,
        address: listings.address, hours: listings.hours, priceFrom: listings.priceFrom,
      })
      .from(listings)
      .where(eq(listings.slug, slug))
      .limit(1);
    if (!l) return null;

    const rows = await db
      .select({
        id: reviews.id, rating: reviews.rating, body: reviews.body,
        tripLabel: reviews.tripLabel, verifiedBooking: reviews.verifiedBooking,
        ownerReply: reviews.ownerReply, createdAt: reviews.createdAt,
        author: users.name,
      })
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(and(eq(reviews.listingId, l.id), eq(reviews.status, 'published')))
      .orderBy(desc(reviews.createdAt))
      .limit(30);

    // Review photos and the listing gallery in two queries, not one per row.
    const shots = rows.length
      ? await db
          .select({ ownerId: media.ownerId, path: media.path, thumbPath: media.thumbPath })
          .from(media)
          .where(eq(media.ownerKind, 'review'))
      : [];

    const gallery = await db
      .select({ id: media.id, path: media.path, thumbPath: media.thumbPath })
      .from(media)
      .where(and(eq(media.ownerKind, 'listing'), eq(media.ownerId, l.id)))
      .orderBy(media.sortOrder, media.id);

    const list: LiveReview[] = rows.map((r) => ({
      ...r,
      verifiedBooking: !!r.verifiedBooking,
      photos: shots
        .filter((s) => s.ownerId === r.id)
        .map(({ path, thumbPath }) => ({ path, thumbPath })),
    }));

    return {
      id: l.id,
      heroMediaId: l.heroMediaId,
      rating: Number(l.rating ?? 0),
      count: l.count ?? 0,
      verified: !!l.verified,
      verifiedAt: l.verifiedAt,
      registration: l.registration,
      overrides: {
        blurb: l.blurb, aboutHtml: l.aboutHtml, phone: l.phone, whatsapp: l.whatsapp,
        website: l.website, address: l.address, hours: l.hours, priceFrom: l.priceFrom,
      },
      gallery,
      reviews: list,
    };
  });
}

/** Has this person already reviewed this listing? */
export async function hasReviewed(listingId: number, userId: number) {
  const mod = await database();
  if (!mod) return false;
  const found = await attempt('hasReviewed', async () => {
    const { db, reviews } = mod;
    const [row] = await db.select({ id: reviews.id }).from(reviews)
      .where(and(eq(reviews.listingId, listingId), eq(reviews.userId, userId))).limit(1);
    return !!row;
  });
  return found ?? false;
}

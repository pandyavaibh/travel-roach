/**
 * Attractions, festivals and itineraries share a shape: they belong to a city,
 * have a slug and a status, and differ only in their fields. One definition
 * table drives one admin list, one form and one actions file — rather than
 * three near-identical copies of the posts screens.
 */

export type RecordKind = 'attractions' | 'events' | 'itineraries';

export type FieldType = 'text' | 'textarea' | 'number' | 'date' | 'checkbox' | 'lines' | 'rich' | 'dayplan';

export type Field = {
  name: string;
  label: string;
  type: FieldType;
  hint?: string;
  required?: boolean;
  max?: number;
  width?: 'full' | 'half' | 'third';
};

export type RecordDef = {
  kind: RecordKind;
  label: string;
  singular: string;
  /** The public URL segment, which differs from the admin kind for itineraries. */
  segment: string;
  titleField: string;
  fields: Field[];
};

const CORE: Field[] = [
  { name: 'cityId', label: 'City', type: 'number', required: true, width: 'half' },
  { name: 'slug', label: 'URL slug', type: 'text', hint: 'Leave blank to build it from the name', width: 'half' },
];

export const RECORDS: Record<RecordKind, RecordDef> = {
  attractions: {
    kind: 'attractions', label: 'Attractions', singular: 'Attraction', segment: 'attractions',
    titleField: 'name',
    fields: [
      ...CORE,
      { name: 'name', label: 'Name', type: 'text', required: true, max: 200 },
      { name: 'category', label: 'Category', type: 'text', hint: 'Fort, Temple, Stepwell, Museum, Garden, Market', width: 'half', max: 80 },
      { name: 'sortRank', label: 'Rank in city', type: 'number', hint: 'Lower shows first', width: 'half' },
      { name: 'summary', label: 'Summary', type: 'textarea', hint: 'One or two sentences, shown on cards', max: 500 },
      { name: 'timings', label: 'Timings', type: 'text', width: 'half', max: 160 },
      { name: 'entryFee', label: 'Entry fee', type: 'text', width: 'half', max: 120 },
      { name: 'timeNeeded', label: 'Time needed', type: 'text', width: 'half', max: 80 },
      { name: 'bestTime', label: 'Best time', type: 'text', width: 'half', max: 120 },
      { name: 'closedOn', label: 'Closed on', type: 'text', width: 'half', max: 120 },
      { name: 'photography', label: 'Photography', type: 'text', width: 'half', max: 160 },
      { name: 'nearestStation', label: 'Nearest station', type: 'text', width: 'half', max: 160 },
      { name: 'accessibility', label: 'Accessibility', type: 'text', width: 'half', max: 160 },
      { name: 'lat', label: 'Latitude', type: 'text', width: 'half' },
      { name: 'lng', label: 'Longitude', type: 'text', width: 'half' },
      { name: 'historyHtml', label: 'History', type: 'rich' },
      { name: 'tips', label: 'Practical tips', type: 'lines', hint: 'One per line' },
    ],
  },
  events: {
    kind: 'events', label: 'Festivals', singular: 'Festival', segment: 'festivals',
    titleField: 'name',
    fields: [
      ...CORE,
      { name: 'name', label: 'Name', type: 'text', required: true, max: 200 },
      { name: 'startsOn', label: 'Starts', type: 'date', required: true, width: 'half' },
      { name: 'endsOn', label: 'Ends', type: 'date', hint: 'Leave blank for a single day', width: 'half' },
      { name: 'venue', label: 'Venue', type: 'text', width: 'half', max: 200 },
      { name: 'season', label: 'Season', type: 'text', hint: 'Winter, Spring, Monsoon, Autumn', width: 'half', max: 40 },
      { name: 'ticketed', label: 'Ticketed', type: 'checkbox', width: 'half' },
      { name: 'priceFrom', label: 'Price from', type: 'text', width: 'half', max: 60 },
      { name: 'bookAhead', label: 'Book ahead', type: 'text', hint: 'e.g. Book 3 months ahead', max: 120 },
      { name: 'note', label: 'What happens', type: 'textarea', max: 2000 },
    ],
  },
  itineraries: {
    kind: 'itineraries', label: 'Itineraries', singular: 'Itinerary', segment: 'itineraries',
    titleField: 'name',
    fields: [
      ...CORE,
      { name: 'name', label: 'Name', type: 'text', required: true, max: 200 },
      { name: 'days', label: 'Days', type: 'number', required: true, width: 'third' },
      { name: 'priceFrom', label: 'Price from (₹)', type: 'number', hint: 'Per person', width: 'third' },
      { name: 'sortOrder', label: 'Sort order', type: 'number', width: 'third' },
      { name: 'route', label: 'Route', type: 'text', hint: 'e.g. 6 stops · walking + rickshaw', max: 255 },
      { name: 'note', label: 'Summary', type: 'textarea', max: 2000 },
      { name: 'inclusions', label: 'Inclusions', type: 'lines', hint: 'One per line — Car, Guide, Entry fees' },
      { name: 'dayPlan', label: 'Day by day', type: 'dayplan' },
    ],
  },
};

export const isRecordKind = (v: string): v is RecordKind => v in RECORDS;
export const RECORD_KINDS = Object.keys(RECORDS) as RecordKind[];

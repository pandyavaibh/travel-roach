import { NextResponse, type NextRequest } from 'next/server';
import { SESSION_COOKIE } from '@/lib/constants';

/**
 * Thin routing layer only: does a session cookie exist. This is deliberate —
 * Next 16 moved auth out of this boundary, so the authoritative role check
 * happens in each page via requireStaff / requireOwner, which can reach the
 * database. A cookie here is a hint, never a permission.
 */
export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const hasSession = req.cookies.has(SESSION_COOKIE);

  /**
   * Pages a signed-out person must be able to reach. Forgotten-password and
   * email-verify links arrive by email, so the visitor has no session by
   * definition — bouncing them to sign-in would break both flows.
   */
  const PUBLIC = ['/admin/login', '/portal/login', '/portal/signup', '/portal/forgot', '/portal/reset', '/portal/verify'];
  const isAuthPage = PUBLIC.some((p) => pathname === p || pathname.startsWith(p + '/'));

  if (!hasSession && !isAuthPage && (pathname.startsWith('/admin') || pathname.startsWith('/portal'))) {
    const url = req.nextUrl.clone();
    url.pathname = pathname.startsWith('/admin') ? '/admin/login' : '/portal/login';
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ['/admin/:path*', '/portal/:path*'] };

'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const TABS: [string, string, string][] = [
  ['Home', '/', 'M3 10.5 12 4l9 6.5V20a1 1 0 0 1-1 1h-5v-6H10v6H5a1 1 0 0 1-1-1z'],
  ['Explore', '/destinations', 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm3.5 5.5-2 5-5 2 2-5z'],
  ['Search', '/search', 'M10.5 4a6.5 6.5 0 1 0 4.03 11.6l4.44 4.43 1.41-1.41-4.43-4.44A6.5 6.5 0 0 0 10.5 4zm0 2a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9z'],
  ['Plan', '/plan', 'M7 2v2H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2h-2V2h-2v2H9V2zm12 8v9H5v-9z'],
];

export default function TabBar() {
  const pathname = usePathname();
  // The admin and owner portal have their own navigation.
  if (pathname.startsWith('/admin') || pathname.startsWith('/portal')) return null;

  return (
    <nav
      aria-label="Main"
      className="fixed inset-x-0 bottom-0 z-[90] border-t border-rule bg-white/95 backdrop-blur md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="grid grid-cols-4">
        {TABS.map(([label, href, d]) => {
          const active = href === '/' ? pathname === '/' : pathname.startsWith(href);
          return (
            <Link
              key={href}
              href={href}
              aria-current={active ? 'page' : undefined}
              className={`flex min-h-[64px] flex-col items-center justify-center gap-1 ${active ? 'text-orange' : 'text-muted-2'}`}
            >
              <svg width="21" height="21" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
                <path d={d} />
              </svg>
              <span className="text-[10px] font-semibold tracking-[.02em]">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

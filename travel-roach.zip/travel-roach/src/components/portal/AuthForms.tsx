'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { portalLoginAction, signupAction, type PortalState } from '@/app/portal/actions';

const initial: PortalState = {};
const field = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';

/** Shared shell for the portal's four auth screens. */
export function AuthCard({ title, lede, children, footer }: {
  title: string; lede: string; children: React.ReactNode; footer?: React.ReactNode;
}) {
  return (
    <main className="grid min-h-[80vh] place-items-center bg-paper p-6">
      <div className="w-full max-w-[420px] rounded-hero border border-rule bg-white p-[clamp(26px,4vw,40px)] shadow-lift">
        <Link href="/" className="flex items-center gap-3">
          <span className="grid h-[34px] w-[34px] place-items-center rounded-full bg-orange font-serif text-[15px] text-white">TR</span>
          <span className="font-serif text-[22px] text-ink">Travel Roach</span>
        </Link>
        <h1 className="m-0 mt-7 font-serif text-[clamp(26px,3vw,34px)] leading-tight">{title}</h1>
        <p className="mt-2.5 text-sm leading-relaxed text-muted-2">{lede}</p>
        {children}
        {footer && <div className="mt-6 border-t border-rule pt-5 text-[13px] text-muted-2">{footer}</div>}
      </div>
    </main>
  );
}

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(portalLoginAction, initial);

  return (
    <AuthCard
      title="Sign in"
      lede="For businesses managing a listing, and travellers writing reviews."
      footer={
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link href="/portal/signup" className="font-semibold text-ink hover:text-orange">Create an account</Link>
          <Link href="/portal/forgot" className="hover:text-orange">Forgotten password</Link>
        </div>
      }
    >
      <form action={action} className="mt-6 flex flex-col gap-2.5">
        {next && <input type="hidden" name="next" value={next} />}
        <input name="email" type="email" autoComplete="email" placeholder="Email" aria-label="Email" className={field} />
        <input name="password" type="password" autoComplete="current-password" placeholder="Password" aria-label="Password" className={field} />
        {state.error && <p className="text-xs text-[#B4441F]">{state.error}</p>}
        <button disabled={pending} className="btn-primary mt-1 min-h-[48px] w-full disabled:opacity-60">
          {pending ? 'Signing in…' : 'Sign in'}
        </button>
      </form>
    </AuthCard>
  );
}

export function SignupForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState(signupAction, initial);

  return (
    <AuthCard
      title="Create an account"
      lede="Businesses manage their own listing. Travellers write reviews. Both are free."
      footer={<>Already have one? <Link href="/portal/login" className="font-semibold text-ink hover:text-orange">Sign in</Link></>}
    >
      <form action={action} className="mt-6 flex flex-col gap-2.5">
        {next && <input type="hidden" name="next" value={next} />}

        <fieldset className="mb-1">
          <legend className="label mb-2">I am</legend>
          <div className="grid grid-cols-2 gap-2">
            {([['owner', 'A business'], ['traveller', 'A traveller']] as const).map(([v, l], i) => (
              <label key={v} className="flex min-h-[46px] cursor-pointer items-center gap-2.5 rounded-card border border-rule px-3.5 text-[13px] font-semibold text-ink-2 has-[:checked]:border-ink has-[:checked]:bg-paper">
                <input type="radio" name="kind" value={v} defaultChecked={i === 0}
                  className="h-[15px] w-[15px] shrink-0 appearance-none rounded-full border border-rule-3 bg-white checked:border-[4px] checked:border-orange" />
                {l}
              </label>
            ))}
          </div>
        </fieldset>

        <input name="name" placeholder="Your name" aria-label="Your name" className={field} />
        <input name="email" type="email" autoComplete="email" placeholder="Email" aria-label="Email" className={field} />
        <input name="password" type="password" autoComplete="new-password" placeholder="Password (10+ characters)" aria-label="Password" className={field} />

        {state.error && <p className="text-xs text-[#B4441F]">{state.error}</p>}

        <p className="mt-1 text-[12px] leading-relaxed text-muted-2">
          Businesses: use an email on your company domain and your claim approves itself. A Gmail address works too, it just needs a person to check it.
        </p>

        <button disabled={pending} className="btn-primary mt-1 min-h-[48px] w-full disabled:opacity-60">
          {pending ? 'Creating…' : 'Create account'}
        </button>
      </form>
    </AuthCard>
  );
}

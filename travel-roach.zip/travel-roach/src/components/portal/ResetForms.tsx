'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { AuthCard } from '@/components/portal/AuthForms';
import { requestResetAction, completeResetAction, type PortalState } from '@/app/portal/actions';

const initial: PortalState = {};
const field = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';

export function ForgotForm() {
  const [state, action, pending] = useActionState(requestResetAction, initial);

  if (state.ok) {
    return (
      <AuthCard title="Check your inbox" lede={state.ok}>
        <Link href="/portal/login" className="btn-outline mt-6">Back to sign in</Link>
      </AuthCard>
    );
  }

  return (
    <AuthCard
      title="Reset your password"
      lede="Enter the address on your account and we will send a link. It works for one hour."
      footer={<Link href="/portal/login" className="font-semibold text-ink hover:text-orange">Back to sign in</Link>}
    >
      <form action={action} className="mt-6 flex flex-col gap-2.5">
        <input name="email" type="email" autoComplete="email" placeholder="Email" aria-label="Email" className={field} />
        {state.error && <p className="text-xs text-[#B4441F]">{state.error}</p>}
        <button disabled={pending} className="btn-primary mt-1 min-h-[48px] w-full disabled:opacity-60">
          {pending ? 'Sending…' : 'Send the link'}
        </button>
      </form>
    </AuthCard>
  );
}

export function ResetForm({ token }: { token: string }) {
  const [state, action, pending] = useActionState(completeResetAction, initial);

  return (
    <AuthCard title="Choose a new password" lede="Ten characters or more. You will be signed in afterwards.">
      <form action={action} className="mt-6 flex flex-col gap-2.5">
        <input type="hidden" name="token" value={token} />
        <input name="password" type="password" autoComplete="new-password"
          placeholder="New password" aria-label="New password" className={field} />
        {state.error && <p className="text-xs text-[#B4441F]">{state.error}</p>}
        <button disabled={pending} className="btn-primary mt-1 min-h-[48px] w-full disabled:opacity-60">
          {pending ? 'Saving…' : 'Save and sign in'}
        </button>
      </form>
    </AuthCard>
  );
}

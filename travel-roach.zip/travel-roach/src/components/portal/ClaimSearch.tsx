'use client';

import { useState, useTransition } from 'react';
import { useActionState } from 'react';
import { searchClaimable, claimListingAction, type PortalState } from '@/app/portal/actions';

type Hit = { id: number; name: string; kind: string; area: string | null; city: string; state: string };

const initial: PortalState = {};

export default function ClaimSearch({ verified }: { verified: boolean }) {
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [chosen, setChosen] = useState<Hit | null>(null);
  const [searching, startSearch] = useTransition();
  const [state, action, pending] = useActionState(claimListingAction, initial);

  const search = (term: string) => {
    setQ(term);
    if (term.trim().length < 2) { setHits(null); return; }
    startSearch(async () => setHits(await searchClaimable(term)));
  };

  if (state.ok) {
    return (
      <div className="card-flat mt-8 p-8 text-center">
        <h2 className="m-0 font-serif text-[26px] leading-tight">Claim submitted</h2>
        <p className="mx-auto mt-3 max-w-[48ch] text-[15px] leading-relaxed text-muted-2">{state.ok}</p>
        <a href="/portal" className="btn-primary mt-6">Back to your dashboard</a>
      </div>
    );
  }

  return (
    <div className="mt-8">
      <label className="label mb-2 block">Search by name</label>
      <input
        value={q}
        onChange={(e) => search(e.target.value)}
        placeholder="The House of MG"
        aria-label="Search for your business"
        className="w-full rounded-card border border-rule bg-white px-4 py-3.5 text-base outline-none focus:border-orange"
      />
      <p className="mt-2 text-[12px] text-muted-2">
        Only listings nobody manages yet are shown. If yours is already claimed, contact us.
      </p>

      {searching && <p className="mt-5 text-[14px] text-muted-2">Searching…</p>}

      {hits && hits.length === 0 && !searching && (
        <p className="mt-5 text-[14px] text-muted-2">
          Nothing matched. Your business may not be listed yet — contact us and we will add it.
        </p>
      )}

      {hits && hits.length > 0 && !chosen && (
        <div className="hair mt-5 [grid-template-columns:1fr]">
          {hits.map((h) => (
            <button key={h.id} type="button" onClick={() => setChosen(h)}
              className="flex flex-wrap items-center justify-between gap-3 bg-white px-5 py-4 text-left hover:bg-paper">
              <span className="min-w-0">
                <span className="block font-serif text-[19px] leading-tight text-ink">{h.name}</span>
                <span className="meta mt-1 block">
                  {[h.kind.replace('-', ' '), h.area, h.city, h.state].filter(Boolean).join(' · ')}
                </span>
              </span>
              <span className="text-[13px] font-semibold text-orange">Claim this →</span>
            </button>
          ))}
        </div>
      )}

      {chosen && (
        <form action={action} className="card-flat mt-6 p-6">
          <input type="hidden" name="listingId" value={chosen.id} />

          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <span className="font-serif text-[22px] leading-tight">{chosen.name}</span>
            <button type="button" onClick={() => setChosen(null)}
              className="text-[13px] font-semibold text-muted-2 hover:text-orange">Choose a different one</button>
          </div>

          <label className="label mb-2 mt-5 block">Anything that helps us confirm it is yours</label>
          <textarea name="evidence" rows={3}
            placeholder="Your role, your registration number, or a page on your website that lists this email address."
            className="w-full resize-y rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange" />
          <p className="mt-2 text-[12px] leading-relaxed text-muted-2">
            Optional. If your email is on the same domain as the listing website, the claim approves itself and
            nobody reads this.
          </p>

          {state.error && <p className="mt-3 text-xs text-[#B4441F]">{state.error}</p>}
          {!verified && (
            <p className="mt-3 text-xs text-[#B4441F]">Confirm your email address first — the link is in your inbox.</p>
          )}

          <button disabled={pending || !verified} className="btn-primary mt-5 min-h-[48px] w-full disabled:opacity-60">
            {pending ? 'Submitting…' : 'Claim this listing'}
          </button>
        </form>
      )}
    </div>
  );
}

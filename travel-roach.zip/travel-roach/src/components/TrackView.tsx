'use client';

import { useEffect } from 'react';

/**
 * Fires one view per mount. Deliberately client-side: server components are
 * cached, so counting there would record a fraction of real traffic.
 */
export default function TrackView({ path, listingId }: { path: string; listingId?: number }) {
  useEffect(() => {
    // sendBeacon survives the page being closed mid-request.
    const payload = JSON.stringify({ path, listingId });
    try {
      if (navigator.sendBeacon) {
        navigator.sendBeacon('/api/view', new Blob([payload], { type: 'application/json' }));
        return;
      }
    } catch {}
    fetch('/api/view', { method: 'POST', body: payload, headers: { 'content-type': 'application/json' }, keepalive: true })
      .catch(() => {});
  }, [path, listingId]);

  return null;
}

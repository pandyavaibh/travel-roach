'use client';

import Link from 'next/link';
import { useActionState, useState } from 'react';
import { submitReviewAction, type ReviewState } from '@/app/review-actions';

const initial: ReviewState = {};
const field = 'w-full rounded-card border border-rule bg-white px-4 py-3 text-sm outline-none focus:border-orange';

export default function ReviewForm({ listingId, listingName, kind, signedIn, emailVerified, alreadyReviewed }: {
  listingId: number; listingName: string; kind: string;
  signedIn: boolean; emailVerified: boolean; alreadyReviewed: boolean;
}) {
  const [state, action, pending] = useActionState(submitReviewAction, initial);
  const [rating, setRating] = useState(0);
  const [photoCount, setPhotoCount] = useState(0);

  const tripHint = kind === 'hotels' ? 'Deluxe double, 3 nights'
    : kind === 'restaurants' ? 'Dinner, table for four'
    : 'Gujarat in 7 days';

  if (!signedIn) {
    return (
      <div className="rounded-card border border-rule bg-paper p-[clamp(20px,2.6vw,28px)]">
        <div className="font-serif text-[22px] leading-tight">Been here?</div>
        <p className="mt-2.5 text-[14px] leading-relaxed text-ink-3">
          Sign in to review {listingName}. We ask for an account so reviews come from real people
          rather than whoever has the most spare time.
        </p>
        <div className="mt-4 flex flex-wrap gap-2">
          <Link href="/portal/login" className="btn-primary">Sign in</Link>
          <Link href="/portal/signup" className="btn-outline">Create an account</Link>
        </div>
      </div>
    );
  }

  if (!emailVerified) {
    return (
      <div className="rounded-card border border-sand-rule bg-sand p-[clamp(20px,2.6vw,28px)]">
        <div className="font-serif text-[22px] leading-tight">Confirm your email first</div>
        <p className="mt-2.5 text-[14px] leading-relaxed text-ink-3">
          The link is in your inbox. It stops one person posting under six names.
        </p>
      </div>
    );
  }

  if (alreadyReviewed) {
    return (
      <div className="rounded-card border border-rule bg-paper p-[clamp(20px,2.6vw,28px)]">
        <div className="font-serif text-[22px] leading-tight">You have reviewed this one</div>
        <p className="mt-2.5 text-[14px] leading-relaxed text-ink-3">
          One review per person, so the average means something.
        </p>
        <Link href="/portal" className="btn-outline mt-4">See your reviews</Link>
      </div>
    );
  }

  if (state.ok) {
    return (
      <div className="rounded-card border border-rule bg-paper p-[clamp(20px,2.6vw,28px)]">
        <div className="font-serif text-[22px] leading-tight">Posted</div>
        <p className="mt-2.5 text-[14px] leading-relaxed text-ink-3">{state.ok}</p>
      </div>
    );
  }

  return (
    <form action={action} className="rounded-card border border-rule bg-paper p-[clamp(20px,2.6vw,28px)]">
      <div className="font-serif text-[22px] leading-tight">Write a review</div>
      <p className="mt-2 text-[13px] leading-relaxed text-muted-2">
        Published straight away. What was actually true on the day is more useful than a verdict.
      </p>

      <input type="hidden" name="listingId" value={listingId} />
      <input type="hidden" name="rating" value={rating} />

      <div className="mt-5">
        <span className="label">Rating</span>
        <div className="mt-2.5 flex gap-1.5">
          {[1, 2, 3, 4, 5].map((n) => (
            <button key={n} type="button" onClick={() => setRating(n)}
              aria-label={`${n} out of 5`} aria-pressed={rating === n}
              className={`h-11 w-11 rounded-full border text-[15px] font-semibold transition-colors ${
                n <= rating ? 'border-orange bg-orange text-white' : 'border-rule bg-white text-muted-2 hover:border-ink'
              }`}>
              {n}
            </button>
          ))}
        </div>
      </div>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-[13px] font-medium text-ink-2">What did you book?</span>
        <input name="tripLabel" placeholder={tripHint} className={field} />
      </label>

      <label className="mt-2.5 block">
        <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Your review</span>
        <textarea name="body" rows={5} required
          placeholder="What happened, what surprised you, and what you would tell a friend to do differently."
          className={field + ' resize-y'} />
      </label>

      <label className="mt-3.5 block">
        <span className="mb-1.5 block text-[13px] font-medium text-ink-2">
          Photos <span className="font-normal text-muted-2">— optional, up to 10</span>
        </span>
        <input type="file" name="photos" accept="image/*" multiple
          onChange={(e) => setPhotoCount(Math.min(e.target.files?.length ?? 0, 10))}
          className="block w-full cursor-pointer rounded-card border border-dashed border-rule-3 bg-white px-4 py-3 text-[13px] file:mr-3 file:rounded-full file:border-0 file:bg-night file:px-4 file:py-2 file:text-[12px] file:font-semibold file:text-paper" />
        {photoCount > 0 && (
          <span className="mt-1.5 block text-[12px] text-muted-2">
            {photoCount} {photoCount === 1 ? 'photo' : 'photos'} selected
          </span>
        )}
      </label>

      {state.error && <p className="mt-3 text-[13px] text-[#B4441F]">{state.error}</p>}

      <button disabled={pending || rating === 0}
        className="btn-primary mt-5 min-h-[48px] w-full disabled:opacity-50">
        {pending ? 'Posting…' : rating === 0 ? 'Pick a rating first' : 'Post review'}
      </button>
    </form>
  );
}

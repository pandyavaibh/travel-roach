'use client';

import { useEffect, useState } from 'react';

/**
 * Temporary comparison control: flips heading type between the serif default
 * and all-sans. Delete this file and the <TypeSwitch /> in layout.tsx once the
 * direction is settled.
 */
export default function TypeSwitch() {
  const [mode, setMode] = useState<'serif' | 'sans'>('serif');

  useEffect(() => {
    const saved = localStorage.getItem('tr-type');
    if (saved === 'sans' || saved === 'serif') setMode(saved);
  }, []);

  useEffect(() => {
    document.documentElement.dataset.type = mode;
    localStorage.setItem('tr-type', mode);
  }, [mode]);

  return (
    <div className="fixed left-4 bottom-[88px] md:bottom-4 z-[95] flex items-center gap-1 rounded-full border border-rule bg-white/95 p-1 shadow-lift backdrop-blur">
      <span className="pl-2.5 pr-1 text-[10px] font-semibold uppercase tracking-[.1em] text-muted">Type</span>
      {(['serif', 'sans'] as const).map((m) => (
        <button
          key={m}
          onClick={() => setMode(m)}
          aria-pressed={mode === m}
          className={`min-h-[30px] rounded-full px-3 text-[11px] font-semibold transition-colors ${
            mode === m ? 'bg-night text-paper' : 'text-ink-2 hover:text-orange'
          }`}
        >
          {m === 'serif' ? 'Serif' : 'Sans'}
        </button>
      ))}
    </div>
  );
}

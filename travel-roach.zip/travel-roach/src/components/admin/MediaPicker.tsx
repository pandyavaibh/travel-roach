'use client';

import { useEffect, useState, useTransition } from 'react';
import { listMedia, uploadForPicker, type PickerItem } from '@/app/admin/media/actions';

/** Modal grid over the media library, with upload in place. */
export default function MediaPicker({ onPick, onClose }: {
  onPick: (m: PickerItem) => void;
  onClose: () => void;
}) {
  const [items, setItems] = useState<PickerItem[] | null>(null);
  const [error, setError] = useState('');
  const [pending, start] = useTransition();

  const refresh = () => { listMedia().then(setItems).catch(() => setError('Could not load the library.')); };
  useEffect(refresh, []);

  const upload = (files: FileList | null) => {
    if (!files?.length) return;
    setError('');
    start(async () => {
      for (const file of Array.from(files)) {
        const fd = new FormData();
        fd.set('file', file);
        const res = await uploadForPicker(fd);
        if ('error' in res) { setError(res.error); return; }
      }
      refresh();
    });
  };

  return (
    <div className="fixed inset-0 z-[95] grid place-items-center bg-[rgba(18,17,13,.6)] p-5" onClick={onClose}>
      <div className="w-full max-w-[720px] max-h-[86vh] overflow-y-auto rounded-hero bg-paper shadow-lift"
        onClick={(e) => e.stopPropagation()}>
        <div className="sticky top-0 flex items-center justify-between gap-4 border-b border-rule bg-paper px-6 py-4">
          <span className="font-serif text-[22px]">Choose an image</span>
          <div className="flex items-center gap-2">
            <label className="btn-outline cursor-pointer">
              {pending ? 'Uploading…' : 'Upload'}
              <input type="file" accept="image/*" multiple className="hidden"
                onChange={(e) => upload(e.target.files)} />
            </label>
            <button type="button" onClick={onClose} className="btn border border-rule text-ink-2">Close</button>
          </div>
        </div>

        <div className="p-6">
          {error && <p className="mb-4 text-[13px] text-[#B4441F]">{error}</p>}

          {items === null ? (
            <p className="text-[14px] text-muted-2">Loading…</p>
          ) : items.length === 0 ? (
            <p className="text-[14px] text-muted-2">Nothing in the library yet. Upload something.</p>
          ) : (
            <div className="grid gap-3 [grid-template-columns:repeat(auto-fill,minmax(130px,1fr))]">
              {items.map((m) => (
                <button key={m.id} type="button" onClick={() => onPick(m)}
                  className="overflow-hidden rounded-card border border-rule bg-white text-left hover:border-ink">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={m.thumbPath || m.path} alt={m.alt ?? ''} loading="lazy"
                    className="block aspect-square w-full object-cover" />
                  <span className="block truncate px-2.5 py-2 text-[11px] font-medium text-ink">{m.filename}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

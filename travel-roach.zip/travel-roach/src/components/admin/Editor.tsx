'use client';

import { useEditor, EditorContent, type Editor as TipTapEditor } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Image from '@tiptap/extension-image';
import { useCallback, useEffect, useState } from 'react';
import MediaPicker from './MediaPicker';

/**
 * Rich text for post bodies. Writes HTML into a hidden input so the form posts
 * to a server action like any other field — no client-side submit handler.
 */
export default function Editor({ name, defaultValue = '' }: { name: string; defaultValue?: string }) {
  const [html, setHtml] = useState(defaultValue);
  const [picking, setPicking] = useState(false);

  const editor = useEditor({
    // Required in Next: Tiptap renders on the client only.
    immediatelyRender: false,
    extensions: [
      StarterKit.configure({ heading: { levels: [2, 3] } }),
      Link.configure({ openOnClick: false, HTMLAttributes: { rel: 'noopener noreferrer' } }),
      Image.configure({ HTMLAttributes: { loading: 'lazy' } }),
    ],
    content: defaultValue,
    editorProps: {
      attributes: {
        class: 'min-h-[360px] px-5 py-4 outline-none prose-editor',
      },
    },
    onUpdate: ({ editor }) => setHtml(editor.getHTML()),
  });

  const addLink = useCallback(() => {
    if (!editor) return;
    const previous = editor.getAttributes('link').href as string | undefined;
    const url = window.prompt('Link URL', previous ?? 'https://');
    if (url === null) return;
    if (url === '') { editor.chain().focus().unsetLink().run(); return; }
    editor.chain().focus().extendMarkRange('link').setLink({ href: url }).run();
  }, [editor]);

  if (!editor) {
    return <div className="rounded-card border border-rule bg-white min-h-[420px]" aria-busy />;
  }

  return (
    <div className="rounded-card border border-rule bg-white overflow-hidden">
      <Toolbar editor={editor} onLink={addLink} onImage={() => setPicking(true)} />
      <EditorContent editor={editor} />
      <input type="hidden" name={name} value={html} />

      {picking && (
        <MediaPicker
          onClose={() => setPicking(false)}
          onPick={(m) => {
            editor.chain().focus().setImage({ src: m.path, alt: m.alt ?? '' }).run();
            setPicking(false);
          }}
        />
      )}
    </div>
  );
}

function Toolbar({ editor, onLink, onImage }: { editor: TipTapEditor; onLink: () => void; onImage: () => void }) {
  // Re-render the toolbar as the selection moves so active states stay honest.
  const [, force] = useState(0);
  useEffect(() => {
    const tick = () => force((n) => n + 1);
    editor.on('selectionUpdate', tick);
    editor.on('transaction', tick);
    return () => { editor.off('selectionUpdate', tick); editor.off('transaction', tick); };
  }, [editor]);

  const btn = (active: boolean) =>
    `inline-flex items-center justify-center min-h-[34px] px-2.5 rounded-md text-[12px] font-semibold transition-colors ${
      active ? 'bg-night text-paper' : 'text-ink-2 hover:bg-paper'
    }`;

  return (
    <div className="flex flex-wrap items-center gap-1 border-b border-rule bg-paper/60 px-2.5 py-2">
      <button type="button" onClick={() => editor.chain().focus().toggleBold().run()}
        className={btn(editor.isActive('bold'))} aria-label="Bold"><strong>B</strong></button>
      <button type="button" onClick={() => editor.chain().focus().toggleItalic().run()}
        className={btn(editor.isActive('italic'))} aria-label="Italic"><em>I</em></button>

      <span className="mx-1 h-5 w-px bg-rule" />

      <button type="button" onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
        className={btn(editor.isActive('heading', { level: 2 }))}>H2</button>
      <button type="button" onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
        className={btn(editor.isActive('heading', { level: 3 }))}>H3</button>
      <button type="button" onClick={() => editor.chain().focus().setParagraph().run()}
        className={btn(editor.isActive('paragraph'))}>Body</button>

      <span className="mx-1 h-5 w-px bg-rule" />

      <button type="button" onClick={() => editor.chain().focus().toggleBulletList().run()}
        className={btn(editor.isActive('bulletList'))}>List</button>
      <button type="button" onClick={() => editor.chain().focus().toggleOrderedList().run()}
        className={btn(editor.isActive('orderedList'))}>1.</button>
      <button type="button" onClick={() => editor.chain().focus().toggleBlockquote().run()}
        className={btn(editor.isActive('blockquote'))}>Quote</button>

      <span className="mx-1 h-5 w-px bg-rule" />

      <button type="button" onClick={onLink} className={btn(editor.isActive('link'))}>Link</button>
      <button type="button" onClick={onImage} className={btn(false)}>Image</button>

      <span className="flex-1" />

      <button type="button" onClick={() => editor.chain().focus().undo().run()}
        className={btn(false)} aria-label="Undo">↺</button>
      <button type="button" onClick={() => editor.chain().focus().redo().run()}
        className={btn(false)} aria-label="Redo">↻</button>
    </div>
  );
}

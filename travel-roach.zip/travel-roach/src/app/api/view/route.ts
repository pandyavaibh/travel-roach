import { NextResponse, type NextRequest } from 'next/server';
import { recordView } from '@/lib/views';

/**
 * Counts a page view. Called by <TrackView /> after hydration, so cached
 * server renders do not under-count and bots that never run JS are excluded.
 */
export async function POST(req: NextRequest) {
  let body: { path?: string; listingId?: number };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  const path = typeof body.path === 'string' ? body.path.slice(0, 300) : '';
  // Only site paths, and never the admin or portal.
  if (!path.startsWith('/') || path.startsWith('/admin') || path.startsWith('/portal') || path.startsWith('/api')) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  await recordView(path, typeof body.listingId === 'number' ? body.listingId : undefined);
  return NextResponse.json({ ok: true });
}

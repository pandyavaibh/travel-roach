import { NextResponse, type NextRequest } from 'next/server';
import { pruneViews, resetMonthlyViews } from '@/lib/views';

/**
 * Monthly housekeeping: zero the owner-dashboard view counters and trim old
 * page_views rows.
 *
 * Point a scheduler at this on the first of each month. Vercel Cron, a
 * cron-job.org hit, or Hostinger's cron panel all work. Protect it with
 * CRON_SECRET so it cannot be triggered by anyone who finds the URL.
 *
 *   curl -H "Authorization: Bearer $CRON_SECRET" https://yoursite.com/api/cron/monthly
 */
export async function GET(req: NextRequest) {
  const secret = process.env.CRON_SECRET;

  // Refuse rather than run unprotected — an open reset endpoint is a liability.
  if (!secret) {
    return NextResponse.json({ error: 'CRON_SECRET is not set' }, { status: 503 });
  }
  if (req.headers.get('authorization') !== `Bearer ${secret}`) {
    return NextResponse.json({ error: 'Unauthorised' }, { status: 401 });
  }

  await resetMonthlyViews();
  await pruneViews(90);

  return NextResponse.json({ ok: true, ran: new Date().toISOString() });
}

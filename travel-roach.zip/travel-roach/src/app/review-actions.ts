'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';
import { and, eq, sql } from 'drizzle-orm';
import { db, reviews, listings, cities, states, enquiries, media } from '@/db';
import { getUser } from '@/lib/auth';
import { saveUpload, QUOTA } from '@/lib/upload';

export type ReviewState = { error?: string; ok?: string };

const schema = z.object({
  listingId: z.coerce.number().int().positive(),
  rating: z.coerce.number().int().min(1).max(5),
  body: z.string().trim().min(30, 'Write at least a couple of sentences — short reviews help nobody').max(4000),
  tripLabel: z.string().trim().max(200).optional().or(z.literal('')),
});

/**
 * Publishes immediately, as agreed. Two brakes: the reviewer must have a
 * confirmed email, and the unique index allows one review per person per
 * listing. Anyone with an enquiry on record gets the verified-booking mark.
 */
export async function submitReviewAction(_p: ReviewState, fd: FormData): Promise<ReviewState> {
  const user = await getUser();
  if (!user) return { error: 'Sign in to post a review.' };
  if (!user.emailVerified) return { error: 'Confirm your email address first — the link is in your inbox.' };

  const parsed = schema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;

  const [existing] = await db.select({ id: reviews.id }).from(reviews)
    .where(and(eq(reviews.listingId, d.listingId), eq(reviews.userId, user.id))).limit(1);
  if (existing) return { error: 'You have already reviewed this one. Edit it from your dashboard.' };

  // A matching enquiry is the evidence of a real visit.
  const [enq] = await db.select({ id: enquiries.id }).from(enquiries)
    .where(and(eq(enquiries.listingId, d.listingId), eq(enquiries.email, user.email))).limit(1);

  const [inserted] = await db.insert(reviews).values({
    listingId: d.listingId,
    userId: user.id,
    rating: d.rating,
    body: d.body,
    tripLabel: d.tripLabel || null,
    verifiedBooking: !!enq,
    status: 'published',
  }).returning({ id: reviews.id });

  // Photos are optional, and a failed upload must not lose the review.
  const files = fd.getAll('photos').filter((x): x is File => x instanceof File && x.size > 0);
  for (const file of files.slice(0, QUOTA.traveller)) {
    try {
      await saveUpload(file, {
        uploadedBy: user.id, ownerKind: 'review', ownerId: inserted.id,
      });
    } catch (err) {
      console.error('[review] photo upload failed', err);
    }
  }

  await recacheRating(d.listingId);
  await revalidateListing(d.listingId);

  return { ok: 'Posted. Thank you — this is the part other travellers actually read.' };
}

/** Ratings are denormalised, so recompute on every publish or hide. */
async function recacheRating(listingId: number) {
  const [agg] = await db
    .select({
      avg: sql<string>`coalesce(round(avg(rating)::numeric, 1), 0)`,
      n: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(and(eq(reviews.listingId, listingId), eq(reviews.status, 'published')));

  await db.update(listings).set({
    ratingCached: agg?.avg ?? '0.0',
    reviewCountCached: agg?.n ?? 0,
  }).where(eq(listings.id, listingId));
}

async function revalidateListing(listingId: number) {
  const [row] = await db
    .select({ slug: listings.slug, kind: listings.kind, city: cities.slug, state: states.slug })
    .from(listings)
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(listings.id, listingId))
    .limit(1);
  if (!row) return;
  const base = `/${row.state}/${row.city}`;
  revalidatePath(`${base}/${row.kind}/${row.slug}`);
  revalidatePath(`${base}/${row.kind}`);
  revalidatePath('/portal');
}

/** Staff moderation. Hiding a review recomputes the cached rating. */
export async function setReviewStatusAction(fd: FormData) {
  const { requireStaff } = await import('@/lib/auth');
  await requireStaff();

  const reviewId = Number(fd.get('reviewId'));
  const status = String(fd.get('status'));
  if (!['published', 'hidden', 'reported'].includes(status)) return;

  const [row] = await db.select({ listingId: reviews.listingId }).from(reviews)
    .where(eq(reviews.id, reviewId)).limit(1);
  if (!row) return;

  await db.update(reviews)
    .set({ status: status as 'published' | 'hidden' | 'reported' })
    .where(eq(reviews.id, reviewId));

  await recacheRating(row.listingId);
  await revalidateListing(row.listingId);
  revalidatePath('/admin/reviews');
}

/** Anyone signed in can flag a review; it stays visible until staff act. */
export async function reportReviewAction(fd: FormData) {
  const user = await getUser();
  if (!user) return;
  const reviewId = Number(fd.get('reviewId'));
  await db.update(reviews).set({ status: 'reported' })
    .where(and(eq(reviews.id, reviewId), eq(reviews.status, 'published')));
  revalidatePath('/admin/reviews');
}

import type { Metadata } from 'next';
import { ForgotForm } from '@/components/portal/ResetForms';

export const metadata: Metadata = { title: 'Reset your password', robots: { index: false, follow: false } };

export default function ForgotPage() {
  return <ForgotForm />;
}

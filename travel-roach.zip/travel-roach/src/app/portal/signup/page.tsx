import { Suspense } from 'react';
import type { Metadata } from 'next';
import { SignupForm } from '@/components/portal/AuthForms';

export const metadata: Metadata = { title: 'Create an account', robots: { index: false, follow: false } };

export default async function PortalSignup({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return <Suspense fallback={null}><SignupForm next={next} /></Suspense>;
}

import { redirect } from 'next/navigation';
import { getUser } from '@/lib/auth';
import ClaimSearch from '@/components/portal/ClaimSearch';

export const dynamic = 'force-dynamic';

export default async function ClaimPage() {
  const user = await getUser();
  if (!user) redirect('/portal/login?next=/portal/claim');

  return (
    <main className="shell py-[clamp(24px,3.4vw,48px)]">
      <div className="mx-auto max-w-[620px]">
        <div className="eyebrow">Businesses</div>
        <h1 className="m-0 mt-3 font-serif text-[clamp(28px,4vw,46px)] leading-[1.04] tracking-[-.025em]">
          Find your business
        </h1>
        <p className="mt-4 text-[15px] leading-[1.6] text-ink-3">
          Claim it and you can manage photos, prices, rooms or menu, and reply to reviews. No listing fee,
          no commission, and claiming does not move you up the page — the directory sorts by rating and
          response time, and that is not for sale.
        </p>

        <ClaimSearch verified={user.emailVerified} />
      </div>
    </main>
  );
}

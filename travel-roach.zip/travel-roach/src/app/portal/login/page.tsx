import { Suspense } from 'react';
import type { Metadata } from 'next';
import { LoginForm } from '@/components/portal/AuthForms';

export const metadata: Metadata = { title: 'Sign in', robots: { index: false, follow: false } };

export default async function PortalLogin({ searchParams }: { searchParams: Promise<{ next?: string }> }) {
  const { next } = await searchParams;
  return <Suspense fallback={null}><LoginForm next={next} /></Suspense>;
}

import Link from 'next/link';
import { redirect } from 'next/navigation';
import { and, desc, eq, sql } from 'drizzle-orm';
import { db, listings, cities, states, enquiries, reviews, media, claims } from '@/db';
import { getUser } from '@/lib/auth';
import { inr } from '@/lib/site';

export const dynamic = 'force-dynamic';

export default async function PortalHome() {
  const user = await getUser();
  if (!user) redirect('/portal/login');
  if (user.role === 'admin' || user.role === 'editor') redirect('/admin');

  // Travellers have no business to manage, so they get their own view.
  if (user.role === 'traveller') return <TravellerHome userId={user.id} name={user.name} />;

  const owned = await db
    .select({
      id: listings.id, name: listings.name, slug: listings.slug, kind: listings.kind,
      verified: listings.verified, verifiedAt: listings.verifiedAt,
      priceFrom: listings.priceFrom, views: listings.viewsThisMonth,
      city: cities.slug, cityName: cities.name, state: states.slug,
    })
    .from(listings)
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(listings.ownerId, user.id));

  if (owned.length === 0) return <NoListing />;

  return (
    <main className="shell py-[clamp(24px,3.4vw,48px)]">
      <div className="eyebrow">Your businesses</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4.4vw,52px)] leading-none tracking-[-.025em]">
        Hello, {user.name.split(' ')[0]}
      </h1>

      <div className="mt-[clamp(26px,3.4vw,44px)] flex flex-col gap-[clamp(26px,3.4vw,44px)]">
        {owned.map((l) => <ListingPanel key={l.id} listing={l} />)}
      </div>

      <p className="mt-10 text-[13px] text-muted-2">
        Managing another business too? <Link href="/portal/claim" className="font-semibold text-ink hover:text-orange">Claim it here</Link>.
      </p>
    </main>
  );
}

type Owned = {
  id: number; name: string; slug: string; kind: string;
  verified: boolean | null; verifiedAt: Date | null;
  priceFrom: number | null; views: number | null;
  city: string; cityName: string; state: string;
};

async function ListingPanel({ listing: l }: { listing: Owned }) {
  const [enq, rev, unreplied, photos] = await Promise.all([
    db.select({ n: sql<number>`count(*)::int` }).from(enquiries)
      .where(and(eq(enquiries.listingId, l.id), eq(enquiries.status, 'new'))),
    db.select({ n: sql<number>`count(*)::int` }).from(reviews)
      .where(and(eq(reviews.listingId, l.id), eq(reviews.status, 'published'))),
    db.select({ n: sql<number>`count(*)::int` }).from(reviews)
      .where(and(eq(reviews.listingId, l.id), eq(reviews.status, 'published'), sql`owner_reply is null`)),
    db.select({ n: sql<number>`count(*)::int` }).from(media)
      .where(and(eq(media.ownerKind, 'listing'), eq(media.ownerId, l.id))),
  ]);

  const rowLabel = l.kind === 'hotels' ? 'Rooms & rates'
    : l.kind === 'restaurants' ? 'Menu & prices'
    : 'Tours & packages';

  // All six carry equal weight, as agreed — no single hero number.
  const cards: [string, string, string, string][] = [
    ['Enquiries', String(enq[0]?.n ?? 0), 'new, unread', `/portal/${l.id}/enquiries`],
    ['Profile views', String(l.views ?? 0), 'this month', `/portal/${l.id}/enquiries`],
    ['Photos', `${photos[0]?.n ?? 0}/50`, 'add and reorder', `/portal/${l.id}/photos`],
    [rowLabel, l.priceFrom ? inr(l.priceFrom) : '—', 'from', `/portal/${l.id}/rows`],
    ['Reviews', String(rev[0]?.n ?? 0), `${unreplied[0]?.n ?? 0} awaiting a reply`, `/portal/${l.id}/reviews`],
    ['Verification', l.verified ? 'Verified' : 'Unverified',
      l.verified && l.verifiedAt ? `checked ${l.verifiedAt.toLocaleDateString('en-GB')}` : 'not yet checked',
      `/portal/${l.id}/details`],
  ];

  return (
    <section>
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-rule pb-4">
        <div className="min-w-0">
          <h2 className="m-0 font-serif text-[clamp(22px,2.6vw,32px)] leading-tight">{l.name}</h2>
          <div className="meta mt-1.5">{l.cityName} · {l.kind.replace('-', ' ')}</div>
        </div>
        <div className="flex flex-wrap gap-2">
          <a href={`/${l.state}/${l.city}/${l.kind}/${l.slug}`} target="_blank" rel="noopener noreferrer"
            className="btn-outline">View public page</a>
          <Link href={`/portal/${l.id}/details`} className="btn-primary">Edit details</Link>
        </div>
      </div>

      <div className="hair mt-px [grid-template-columns:repeat(auto-fit,minmax(200px,1fr))]">
        {cards.map(([label, value, note, href]) => (
          <Link key={label} href={href} className="block bg-white p-5 pb-6 hover:bg-paper">
            <div className="label">{label}</div>
            <div className="mt-3 font-serif text-[clamp(26px,3vw,36px)] leading-none text-ink">{value}</div>
            <div className="meta mt-2">{note}</div>
          </Link>
        ))}
      </div>
    </section>
  );
}

async function TravellerHome({ userId, name }: { userId: number; name: string }) {
  const mine = await db
    .select({
      id: reviews.id, rating: reviews.rating, body: reviews.body,
      createdAt: reviews.createdAt, verifiedBooking: reviews.verifiedBooking,
      ownerReply: reviews.ownerReply,
      listing: listings.name, slug: listings.slug, kind: listings.kind,
      city: cities.slug, state: states.slug,
    })
    .from(reviews)
    .innerJoin(listings, eq(reviews.listingId, listings.id))
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(reviews.userId, userId))
    .orderBy(desc(reviews.createdAt));

  return (
    <main className="shell py-[clamp(24px,3.4vw,48px)]">
      <div className="eyebrow">Your reviews</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4.4vw,52px)] leading-none tracking-[-.025em]">
        Hello, {name.split(' ')[0]}
      </h1>

      {mine.length === 0 ? (
        <div className="card-flat mt-8 p-10 text-center">
          <h2 className="m-0 font-serif text-[26px] leading-tight">You have not reviewed anything yet</h2>
          <p className="mx-auto mt-3 max-w-[48ch] text-[15px] leading-relaxed text-muted-2">
            Reviews go on the page of the hotel, restaurant or agent itself. Find the place you stayed or ate,
            and the form is at the bottom.
          </p>
          <Link href="/destinations" className="btn-primary mt-6">Browse destinations</Link>
        </div>
      ) : (
        <div className="mt-8 flex flex-col gap-3">
          {mine.map((r) => (
            <div key={r.id} className="card-flat p-6">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <a href={`/${r.state}/${r.city}/${r.kind}/${r.slug}`}
                  className="font-serif text-[21px] leading-tight text-ink hover:text-orange">{r.listing}</a>
                <span className="meta">
                  {r.rating.toFixed(1)}
                  {r.verifiedBooking && ' · verified booking'}
                  {r.createdAt && ` · ${r.createdAt.toLocaleDateString('en-GB')}`}
                </span>
              </div>
              <p className="mt-3 text-sm leading-[1.65] text-ink-3">{r.body}</p>
              {r.ownerReply && (
                <div className="mt-4 border-l-2 border-orange pl-4">
                  <div className="label">Reply from the business</div>
                  <p className="mt-2 text-sm leading-[1.65] text-ink-3">{r.ownerReply}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </main>
  );
}

async function NoListing() {
  const pending = await db.select({ n: sql<number>`count(*)::int` }).from(claims)
    .where(eq(claims.status, 'pending'));

  return (
    <main className="shell py-[clamp(32px,5vw,72px)]">
      <div className="mx-auto max-w-[56ch] text-center">
        <div className="eyebrow">Businesses</div>
        <h1 className="m-0 mt-4 font-serif text-[clamp(30px,4.4vw,52px)] leading-[1.04] tracking-[-.025em]">
          Claim your listing
        </h1>
        <p className="mt-5 text-[clamp(15px,1.5vw,17px)] leading-[1.6] text-ink-3">
          Find your business, claim it, and you can manage its photos, prices, rooms or menu, and reply to reviews.
          There are no listing fees and no commission — enquiries come straight to you.
        </p>
        <Link href="/portal/claim" className="btn-primary mt-7">Find your business</Link>
        {(pending[0]?.n ?? 0) > 0 && (
          <p className="mt-5 text-[13px] text-muted-2">
            Already claimed one? Claims that need checking by hand usually take a working day.
          </p>
        )}
      </div>
    </main>
  );
}

import Link from 'next/link';
import { getUser } from '@/lib/auth';
import { portalLogoutAction } from './actions';

export const metadata = { robots: { index: false, follow: false } };

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const user = await getUser();

  // The auth screens render their own shell, so an unauthenticated visitor
  // passes straight through.
  if (!user) return <>{children}</>;

  return (
    <div className="min-h-screen bg-paper">
      <header className="sticky top-0 z-[80] border-b border-rule bg-paper/95 backdrop-blur">
        <div className="shell flex flex-wrap items-center gap-x-8 gap-y-3 py-3.5">
          <Link href="/portal" className="flex shrink-0 items-center gap-3">
            <span className="grid h-[34px] w-[34px] place-items-center rounded-full bg-orange font-serif text-[15px] text-white">TR</span>
            <span className="font-serif text-[21px] text-ink">Your dashboard</span>
          </Link>

          <span className="flex-1" />

          <div className="flex items-center gap-2.5">
            <span className="hidden text-[13px] font-medium text-muted-2 sm:inline">{user.name}</span>
            <Link href="/" className="btn-outline">View site</Link>
            <form action={portalLogoutAction}>
              <button className="btn border border-rule text-ink-2">Sign out</button>
            </form>
          </div>
        </div>
      </header>

      {!user.emailVerified && <VerifyBanner />}

      {children}
    </div>
  );
}

function VerifyBanner() {
  return (
    <div className="border-b border-sand-rule bg-sand">
      <div className="shell flex flex-wrap items-center justify-between gap-4 py-3.5">
        <p className="m-0 text-[13px] leading-relaxed text-ink-3">
          <strong className="font-semibold">Confirm your email</strong> to claim a listing or post a review.
          The link is in your inbox.
        </p>
        <Link href="/portal/resend" className="text-[13px] font-semibold text-orange-deep hover:text-orange">
          Send it again
        </Link>
      </div>
    </div>
  );
}

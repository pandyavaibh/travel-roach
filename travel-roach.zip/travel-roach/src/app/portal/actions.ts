'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { and, eq, sql } from 'drizzle-orm';
import { headers } from 'next/headers';
import { unlink } from 'fs/promises';
import path from 'path';
import { db, users, listings, claims, cities, states, media, listingRows, enquiries } from '@/db';
import { saveUpload, QUOTA } from '@/lib/upload';
import {
  createSession, destroySession, hashPassword, verifyPassword,
  token, getUser, domainMatches, requireOwner,
} from '@/lib/auth';
import { mailVerify, mailReset, mailClaimPending, mailClaimApproved } from '@/lib/email';

export type PortalState = { error?: string; ok?: string };

const SITE = () => process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

/* ---------- Signup ---------- */

const signup = z.object({
  name: z.string().trim().min(2, 'Enter your name').max(160),
  email: z.string().trim().email('Enter a valid email'),
  password: z.string().min(10, 'Use at least 10 characters'),
  business: z.string().trim().max(200).optional(),
});

export async function signupAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const parsed = signup.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;
  const email = d.email.toLowerCase();

  const [exists] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
  // Do not confirm whether an account exists — that is an enumeration leak.
  if (exists) {
    return { ok: 'Check your email. If that address has no account yet, a confirmation link is on its way.' };
  }

  const verifyToken = token();
  await db.insert(users).values({
    name: d.name, email,
    passwordHash: await hashPassword(d.password),
    role: 'owner', emailVerified: false, verifyToken,
  });

  await mailVerify(email, d.name, `${SITE()}/portal/verify?t=${verifyToken}`);
  return { ok: 'Check your email. If that address has no account yet, a confirmation link is on its way.' };
}

/* ---------- Verify ---------- */

export async function verifyEmailAction(t: string): Promise<boolean> {
  if (!t) return false;
  const [u] = await db.select().from(users).where(eq(users.verifyToken, t)).limit(1);
  if (!u) return false;
  await db.update(users)
    .set({ emailVerified: true, verifyToken: null })
    .where(eq(users.id, u.id));
  await createSession(u.id);
  return true;
}

/* ---------- Login ---------- */

const login = z.object({
  email: z.string().trim().email('Enter a valid email'),
  password: z.string().min(1, 'Enter your password'),
  next: z.string().optional(),
});

export async function portalLoginAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const parsed = login.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const { email, password, next } = parsed.data;

  const [u] = await db.select().from(users).where(eq(users.email, email.toLowerCase())).limit(1);
  if (!u || !(await verifyPassword(password, u.passwordHash))) {
    return { error: 'Email or password is wrong.' };
  }
  if (!u.emailVerified) {
    return { error: 'Confirm your email first — check your inbox for the link.' };
  }

  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, u.id));
  await createSession(u.id);
  redirect(next && next.startsWith('/portal') ? next : '/portal');
}

export async function portalLogoutAction() {
  await destroySession();
  redirect('/portal/login');
}

/* ---------- Password reset ---------- */

export async function requestResetAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const email = String(fd.get('email') ?? '').trim().toLowerCase();
  if (!email.includes('@')) return { error: 'Enter a valid email' };

  const [u] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (u) {
    const t = token();
    await db.update(users)
      .set({ resetToken: t, resetExpires: new Date(Date.now() + 3600_000) })
      .where(eq(users.id, u.id));
    await mailReset(email, `${SITE()}/portal/reset?t=${t}`);
  }
  // Same response either way.
  return { ok: 'If that address has an account, a reset link is on its way. It works for one hour.' };
}

export async function completeResetAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const t = String(fd.get('t') ?? '');
  const password = String(fd.get('password') ?? '');
  if (password.length < 10) return { error: 'Use at least 10 characters' };

  const [u] = await db.select().from(users).where(eq(users.resetToken, t)).limit(1);
  if (!u || !u.resetExpires || u.resetExpires < new Date()) {
    return { error: 'That link has expired. Request a new one.' };
  }

  await db.update(users).set({
    passwordHash: await hashPassword(password),
    resetToken: null, resetExpires: null, emailVerified: true,
  }).where(eq(users.id, u.id));

  await createSession(u.id);
  redirect('/portal');
}

/* ---------- Claims ---------- */

export async function claimAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const user = await getUser();
  if (!user) return { error: 'Sign in first.' };
  if (!user.emailVerified) return { error: 'Confirm your email before claiming a listing.' };

  const listingId = Number(fd.get('listingId'));
  const evidence = String(fd.get('evidence') ?? '').slice(0, 2000);
  if (!listingId) return { error: 'Pick a listing.' };

  const [listing] = await db.select().from(listings).where(eq(listings.id, listingId)).limit(1);
  if (!listing) return { error: 'That listing does not exist.' };
  if (listing.ownerId) return { error: 'That listing already has an owner. Contact us if this is wrong.' };

  const [already] = await db.select({ id: claims.id }).from(claims)
    .where(and(eq(claims.listingId, listingId), eq(claims.userId, user.id))).limit(1);
  if (already) return { error: 'You already have a claim on this listing.' };

  // Domain match is the only thing that auto-approves. Everything else queues.
  const auto = domainMatches(user.email, listing.website);

  await db.insert(claims).values({
    listingId, userId: user.id,
    status: auto ? 'approved' : 'pending',
    method: auto ? 'domain-match' : 'manual',
    evidence: evidence || null,
    reviewedAt: auto ? new Date() : null,
  });

  if (auto) {
    await db.update(listings).set({ ownerId: user.id }).where(eq(listings.id, listingId));
    await db.update(users).set({ role: 'owner' }).where(eq(users.id, user.id));
    await mailClaimApproved(user.email, listing.name, `${SITE()}/portal`);
    revalidatePath('/portal');
    return { ok: `\u2713 ${listing.name} is yours. Your email domain matched the listing website.` };
  }

  await mailClaimPending(user.email, listing.name);
  return { ok: `Claim received for ${listing.name}. We check these by hand, usually within a working day.` };
}

/* ---------- Owner edits ---------- */

/** Confirms the signed-in user owns this listing. Admins pass through. */
async function ownedListing(listingId: number) {
  const user = await requireOwner();
  const [l] = await db.select().from(listings).where(eq(listings.id, listingId)).limit(1);
  if (!l) redirect('/portal');
  if (user.role !== 'admin' && l.ownerId !== user.id) redirect('/portal');
  return { user, listing: l };
}

const details = z.object({
  listingId: z.coerce.number().int().positive(),
  blurb: z.string().trim().max(600),
  aboutHtml: z.string().max(20000),
  phone: z.string().trim().max(40),
  whatsapp: z.string().trim().max(40),
  email: z.string().trim().max(200),
  website: z.string().trim().max(300),
  address: z.string().trim().max(300),
  hours: z.string().trim().max(160),
  priceFrom: z.coerce.number().int().min(0).max(10_000_000),
});

export async function saveListingAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const parsed = details.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;

  const { listing } = await ownedListing(d.listingId);

  await db.update(listings).set({
    blurb: d.blurb || null,
    aboutHtml: d.aboutHtml || null,
    phone: d.phone || null,
    whatsapp: d.whatsapp || null,
    email: d.email || null,
    website: d.website || null,
    address: d.address || null,
    hours: d.hours || null,
    priceFrom: d.priceFrom || null,
  }).where(eq(listings.id, d.listingId));

  await revalidateListing(d.listingId);
  return { ok: 'Saved. Your listing is updated on the live site.' };
}

export async function replyToReviewAction(fd: FormData) {
  const { reviews } = await import('@/db');
  const reviewId = Number(fd.get('reviewId'));
  const listingId = Number(fd.get('listingId'));
  const reply = String(fd.get('reply') ?? '').trim().slice(0, 2000);
  if (!reviewId || !listingId) return;

  await ownedListing(listingId);
  await db.update(reviews)
    .set({ ownerReply: reply || null, ownerRepliedAt: reply ? new Date() : null })
    .where(and(eq(reviews.id, reviewId), eq(reviews.listingId, listingId)));

  revalidatePath('/portal/reviews');
}

/* ---------- Shared helpers ---------- */

/**
 * Owner edits show on the public page immediately, so every write clears the
 * profile, its directory section, and the city hub that links to it.
 */
async function revalidateListing(listingId: number) {
  const [row] = await db
    .select({ slug: listings.slug, kind: listings.kind, city: cities.slug, state: states.slug })
    .from(listings)
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(listings.id, listingId))
    .limit(1);
  if (!row) return;
  const base = `/${row.state}/${row.city}`;
  revalidatePath(`${base}/${row.kind}/${row.slug}`);
  revalidatePath(`${base}/${row.kind}`);
  revalidatePath(base);
  revalidatePath('/portal');
}

/* ---------- Photos ---------- */

export async function uploadListingPhotoAction(fd: FormData): Promise<{ error?: string } | void> {
  const listingId = Number(fd.get('listingId'));
  const { user } = await ownedListing(listingId);
  const file = fd.get('file');
  if (!(file instanceof File)) return { error: 'No file received.' };

  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(media)
    .where(and(eq(media.ownerKind, 'listing'), eq(media.ownerId, listingId)));
  if (n >= QUOTA.owner) {
    return { error: `You have reached ${QUOTA.owner} photos. Delete one to add another.` };
  }

  const res = await saveUpload(file, {
    uploadedBy: user.id, ownerKind: 'listing', ownerId: listingId,
  });
  if (!res.ok) return { error: res.error };

  // First photo becomes the header image automatically.
  const [l] = await db.select({ heroMediaId: listings.heroMediaId }).from(listings)
    .where(eq(listings.id, listingId)).limit(1);
  if (!l?.heroMediaId) {
    await db.update(listings).set({ heroMediaId: res.id }).where(eq(listings.id, listingId));
  }

  await revalidateListing(listingId);
}

export async function deleteListingPhotoAction(fd: FormData) {
  const listingId = Number(fd.get('listingId'));
  await ownedListing(listingId);
  const mediaId = Number(fd.get('mediaId'));

  const [row] = await db.select().from(media)
    .where(and(eq(media.id, mediaId), eq(media.ownerId, listingId))).limit(1);
  if (!row) return;

  const root = process.env.UPLOAD_DIR || './public/uploads';
  for (const p of [row.path, row.thumbPath]) {
    if (!p) continue;
    try { await unlink(path.join(root, p.replace(/^\/uploads\//, ''))); } catch {}
  }
  await db.delete(media).where(eq(media.id, mediaId));

  // If that was the header, promote whatever is left.
  const [l] = await db.select({ heroMediaId: listings.heroMediaId }).from(listings)
    .where(eq(listings.id, listingId)).limit(1);
  if (l?.heroMediaId === mediaId) {
    const [next] = await db.select({ id: media.id }).from(media)
      .where(and(eq(media.ownerKind, 'listing'), eq(media.ownerId, listingId)))
      .orderBy(media.sortOrder, media.id).limit(1);
    await db.update(listings).set({ heroMediaId: next?.id ?? null }).where(eq(listings.id, listingId));
  }

  await revalidateListing(listingId);
}

export async function setHeroPhotoAction(fd: FormData) {
  const listingId = Number(fd.get('listingId'));
  await ownedListing(listingId);
  const mediaId = Number(fd.get('mediaId'));

  const [row] = await db.select({ id: media.id }).from(media)
    .where(and(eq(media.id, mediaId), eq(media.ownerId, listingId))).limit(1);
  if (!row) return;

  await db.update(listings).set({ heroMediaId: mediaId }).where(eq(listings.id, listingId));
  await revalidateListing(listingId);
}

/* ---------- Rooms / menu / packages ---------- */

const rowSchema = z.object({
  listingId: z.coerce.number().int().positive(),
  rowId: z.coerce.number().int().optional(),
  name: z.string().trim().min(2, 'Give it a name').max(200),
  meta: z.string().trim().max(200).optional().or(z.literal('')),
  note: z.string().trim().max(2000).optional().or(z.literal('')),
  price: z.string().trim().max(60).optional().or(z.literal('')),
});

export async function saveRowAction(_p: PortalState, fd: FormData): Promise<PortalState> {
  const parsed = rowSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };
  const d = parsed.data;
  await ownedListing(d.listingId);

  const values = {
    listingId: d.listingId,
    name: d.name,
    meta: d.meta || null,
    note: d.note || null,
    price: d.price || null,
  };

  if (d.rowId) {
    await db.update(listingRows).set(values).where(
      and(eq(listingRows.id, d.rowId), eq(listingRows.listingId, d.listingId)));
  } else {
    const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(listingRows)
      .where(eq(listingRows.listingId, d.listingId));
    await db.insert(listingRows).values({ ...values, sortOrder: n });
  }

  await revalidateListing(d.listingId);
  return { ok: d.rowId ? 'Updated.' : 'Added.' };
}

export async function deleteRowAction(fd: FormData) {
  const listingId = Number(fd.get('listingId'));
  await ownedListing(listingId);
  await db.delete(listingRows).where(
    and(eq(listingRows.id, Number(fd.get('rowId'))), eq(listingRows.listingId, listingId)));
  await revalidateListing(listingId);
}

/* ---------- Enquiries ---------- */

export async function setEnquiryStatusAction(fd: FormData) {
  const listingId = Number(fd.get('listingId'));
  await ownedListing(listingId);
  const status = String(fd.get('status'));
  if (!['new', 'read', 'replied', 'spam'].includes(status)) return;
  await db.update(enquiries).set({ status: status as 'new' | 'read' | 'replied' | 'spam' })
    .where(and(eq(enquiries.id, Number(fd.get('enquiryId'))), eq(enquiries.listingId, listingId)));
  revalidatePath(`/portal/${listingId}/enquiries`);
  revalidatePath('/portal');
}

import Link from 'next/link';
import type { Metadata } from 'next';
import { verifyEmailAction } from '../actions';
import { AuthCard } from '@/components/portal/AuthForms';

export const metadata: Metadata = { title: 'Confirm your email', robots: { index: false, follow: false } };

export default async function VerifyPage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const { t } = await searchParams;
  const ok = await verifyEmailAction(t ?? '');

  return (
    <AuthCard
      title={ok ? 'Email confirmed' : 'That link did not work'}
      lede={ok
        ? 'You can now claim a listing or write a review.'
        : 'It may have already been used, or it may have expired. Sign in and ask for another.'}
    >
      <div className="mt-6 flex flex-wrap gap-2">
        <Link href="/portal" className="btn-primary">Go to your dashboard</Link>
        {!ok && <Link href="/portal/login" className="btn-outline">Sign in</Link>}
      </div>
    </AuthCard>
  );
}

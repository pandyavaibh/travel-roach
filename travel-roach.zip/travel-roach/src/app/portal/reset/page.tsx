import Link from 'next/link';
import type { Metadata } from 'next';
import { ResetForm } from '@/components/portal/ResetForms';
import { AuthCard } from '@/components/portal/AuthForms';

export const metadata: Metadata = { title: 'Set a new password', robots: { index: false, follow: false } };

export default async function ResetPage({ searchParams }: { searchParams: Promise<{ t?: string }> }) {
  const { t } = await searchParams;

  if (!t) {
    return (
      <AuthCard title="Nothing to reset" lede="That link is missing its token. Ask for a new one.">
        <Link href="/portal/forgot" className="btn-primary mt-6">Request a reset link</Link>
      </AuthCard>
    );
  }

  return <ResetForm token={t} />;
}

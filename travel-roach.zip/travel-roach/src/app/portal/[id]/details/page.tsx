import { eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { db, listings } from '@/db';
import { requireOwner } from '@/lib/auth';
import DetailsForm from './DetailsForm';

export const dynamic = 'force-dynamic';

export default async function DetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireOwner();

  const [l] = await db.select().from(listings).where(eq(listings.id, Number(id))).limit(1);
  if (!l) notFound();

  return (
    <main className="shell py-[clamp(22px,3vw,40px)]">
      <DetailsForm listing={{
        id: l.id,
        kind: l.kind,
        blurb: l.blurb ?? '',
        aboutHtml: l.aboutHtml ?? '',
        phone: l.phone ?? '',
        whatsapp: l.whatsapp ?? '',
        email: l.email ?? '',
        website: l.website ?? '',
        address: l.address ?? '',
        hours: l.hours ?? '',
        priceFrom: l.priceFrom ?? 0,
        verified: !!l.verified,
        registration: l.registration ?? '',
      }} />
    </main>
  );
}

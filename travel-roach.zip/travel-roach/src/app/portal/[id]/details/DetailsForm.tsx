'use client';

import { useActionState } from 'react';
import { saveListingAction, type PortalState } from '@/app/portal/actions';

const initial: PortalState = {};
const field = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';

type L = {
  id: number; kind: string; blurb: string; aboutHtml: string;
  phone: string; whatsapp: string; email: string; website: string;
  address: string; hours: string; priceFrom: number;
  verified: boolean; registration: string;
};

const PRICE_LABEL: Record<string, string> = {
  hotels: 'Lowest nightly rate (₹)',
  restaurants: 'Typical cost for two (₹)',
  'travel-agents': 'Lowest per-person price (₹)',
};

export default function DetailsForm({ listing: l }: { listing: L }) {
  const [state, action, pending] = useActionState(saveListingAction, initial);

  return (
    <form action={action} className="grid items-start gap-[clamp(20px,2.6vw,36px)] [grid-template-columns:repeat(auto-fit,minmax(290px,1fr))]">
      <input type="hidden" name="listingId" value={l.id} />

      <div className="min-w-0">
        <div className="label">About</div>
        <div className="mt-3.5 flex flex-col gap-2.5">
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">
              Short description — shown on listing cards
            </span>
            <textarea name="blurb" rows={3} defaultValue={l.blurb} maxLength={600}
              placeholder="One or two sentences on what makes this place worth choosing."
              className={field + ' resize-y'} />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">
              Full description — shown on your page
            </span>
            <textarea name="aboutHtml" rows={7} defaultValue={l.aboutHtml}
              placeholder="Longer copy. Plain paragraphs are fine."
              className={field + ' resize-y'} />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">
              {PRICE_LABEL[l.kind] ?? 'Starting price (₹)'}
            </span>
            <input name="priceFrom" type="number" min={0} defaultValue={l.priceFrom || ''} className={field} />
          </label>
        </div>

        {state.error && <p className="mt-3 text-[13px] text-[#B4441F]">{state.error}</p>}
        {state.ok && <p className="mt-3 text-[13px] text-trust">{state.ok}</p>}
        <button disabled={pending} className="btn-primary mt-5 min-h-[48px] disabled:opacity-60">
          {pending ? 'Saving…' : 'Save changes'}
        </button>
      </div>

      <div className="flex flex-col gap-5">
        <div>
          <div className="label">Contact</div>
          <div className="mt-3.5 flex flex-col gap-2.5">
            {([
              ['phone', 'Phone', 'tel', l.phone],
              ['whatsapp', 'WhatsApp', 'tel', l.whatsapp],
              ['email', 'Email — where enquiries go', 'email', l.email],
              ['website', 'Website', 'url', l.website],
            ] as const).map(([name, label, type, value]) => (
              <label key={name} className="block">
                <span className="mb-1.5 block text-[13px] font-medium text-ink-2">{label}</span>
                <input name={name} type={type} defaultValue={value} className={field} />
              </label>
            ))}
          </div>
        </div>

        <div>
          <div className="label">Where and when</div>
          <div className="mt-3.5 flex flex-col gap-2.5">
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Address</span>
              <input name="address" defaultValue={l.address} className={field} />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Opening hours</span>
              <input name="hours" defaultValue={l.hours}
                placeholder="11:00–15:00 · 19:00–22:30" className={field} />
            </label>
          </div>
        </div>

        <div className="rounded-card border border-rule bg-white p-5">
          <div className="label">Verification</div>
          <p className="mt-2.5 text-[13px] leading-relaxed text-ink-3">
            {l.verified
              ? 'Your listing carries the verified mark. ' + (l.registration || '')
              : 'Not yet verified. Email your registration or trading licence number to claims@travelroach.com and we will check it.'}
          </p>
          <p className="mt-3 text-[12px] leading-relaxed text-muted-2">
            Verification does not change your position in the directory. Listings sort by rating
            and response time, and placement is not for sale.
          </p>
        </div>
      </div>
    </form>
  );
}

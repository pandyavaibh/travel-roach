import { eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { db, listings, listingRows } from '@/db';
import { requireOwner } from '@/lib/auth';
import RowEditor from './RowEditor';

export const dynamic = 'force-dynamic';

const COPY: Record<string, { title: string; hint: string; nameLabel: string; metaLabel: string; metaHint: string; priceHint: string }> = {
  hotels: {
    title: 'Rooms & rates',
    hint: 'One entry per room type. Travellers compare these before they enquire, so be specific about what is included.',
    nameLabel: 'Room name', metaLabel: 'Beds and size', metaHint: '1 king · 30 sqm',
    priceHint: '₹4,200 per night',
  },
  restaurants: {
    title: 'Menu & prices',
    hint: 'One entry per menu, thali or set. You do not need every dish — the shape of the offer is what people want.',
    nameLabel: 'Menu name', metaLabel: 'When it runs', metaHint: 'Nov – Feb · unlimited',
    priceHint: '₹850 per person',
  },
  'travel-agents': {
    title: 'Tours & packages',
    hint: 'One entry per trip you run. Enquiries mentioning a package convert better than general ones.',
    nameLabel: 'Package name', metaLabel: 'Length and format', metaHint: '3 days · car + guide',
    priceHint: '₹16,500 per person',
  },
};

export default async function RowsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireOwner();
  const listingId = Number(id);

  const [l] = await db.select({ kind: listings.kind }).from(listings)
    .where(eq(listings.id, listingId)).limit(1);
  if (!l) notFound();

  const rows = await db.select().from(listingRows)
    .where(eq(listingRows.listingId, listingId))
    .orderBy(listingRows.sortOrder, listingRows.id);

  const copy = COPY[l.kind] ?? COPY.hotels;

  return (
    <main className="shell py-[clamp(22px,3vw,40px)]">
      <p className="m-0 max-w-[62ch] text-[15px] leading-relaxed text-ink-3">{copy.hint}</p>
      <RowEditor
        listingId={listingId}
        rows={rows.map((r) => ({
          id: r.id, name: r.name, meta: r.meta ?? '', note: r.note ?? '', price: r.price ?? '',
        }))}
        copy={copy}
      />
    </main>
  );
}

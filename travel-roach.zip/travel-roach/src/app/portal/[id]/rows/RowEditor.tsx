'use client';

import { useActionState, useState } from 'react';
import { saveRowAction, deleteRowAction, type PortalState } from '@/app/portal/actions';

const initial: PortalState = {};
const field = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';

type Row = { id: number; name: string; meta: string; note: string; price: string };
type Copy = { title: string; nameLabel: string; metaLabel: string; metaHint: string; priceHint: string };

export default function RowEditor({ listingId, rows, copy }: {
  listingId: number; rows: Row[]; copy: Copy;
}) {
  const [state, action, pending] = useActionState(saveRowAction, initial);
  const [editing, setEditing] = useState<Row | null>(null);
  const [adding, setAdding] = useState(false);

  const showForm = adding || editing !== null;

  return (
    <>
      {!showForm && (
        <button onClick={() => setAdding(true)} className="btn-primary mt-6">
          Add {copy.nameLabel.toLowerCase()}
        </button>
      )}

      {showForm && (
        <form
          action={action}
          key={editing?.id ?? 'new'}
          className="mt-6 rounded-card border border-rule bg-white p-[clamp(18px,2.4vw,28px)]"
        >
          <div className="font-serif text-[22px] leading-tight">
            {editing ? 'Edit' : 'New'} {copy.nameLabel.toLowerCase()}
          </div>

          <input type="hidden" name="listingId" value={listingId} />
          {editing && <input type="hidden" name="rowId" value={editing.id} />}

          <div className="mt-5 grid gap-2.5 [grid-template-columns:repeat(auto-fit,minmax(220px,1fr))]">
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">{copy.nameLabel}</span>
              <input name="name" defaultValue={editing?.name ?? ''} required className={field} />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">{copy.metaLabel}</span>
              <input name="meta" defaultValue={editing?.meta ?? ''}
                placeholder={copy.metaHint} className={field} />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Price</span>
              <input name="price" defaultValue={editing?.price ?? ''}
                placeholder={copy.priceHint} className={field} />
            </label>
          </div>

          <label className="mt-2.5 block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">
              What it includes
            </span>
            <textarea name="note" rows={3} defaultValue={editing?.note ?? ''}
              placeholder="A sentence or two. What is included, what is not, anything worth knowing before booking."
              className={field + ' resize-y'} />
          </label>

          {state.error && <p className="mt-3 text-[13px] text-[#B4441F]">{state.error}</p>}
          {state.ok && <p className="mt-3 text-[13px] text-trust">{state.ok}</p>}

          <div className="mt-5 flex flex-wrap gap-2">
            <button disabled={pending} className="btn-primary disabled:opacity-60">
              {pending ? 'Saving…' : editing ? 'Save changes' : 'Add'}
            </button>
            <button type="button" onClick={() => { setAdding(false); setEditing(null); }}
              className="btn-outline">Cancel</button>
          </div>
        </form>
      )}

      {rows.length === 0 ? (
        <p className="mt-7 text-[15px] text-muted-2">Nothing listed yet.</p>
      ) : (
        <div className="mt-7 flex flex-col gap-3">
          {rows.map((r) => (
            <div key={r.id} className="grid items-center gap-4 rounded-card border border-rule bg-white p-5 [grid-template-columns:repeat(auto-fit,minmax(200px,1fr))]">
              <div className="min-w-0">
                <div className="font-serif text-[20px] leading-tight text-ink">{r.name}</div>
                {r.meta && <div className="meta mt-1.5">{r.meta}</div>}
                {r.note && <p className="mt-2 text-[13px] leading-relaxed text-ink-3">{r.note}</p>}
              </div>
              <div className="flex flex-wrap items-center justify-end gap-2">
                {r.price && <span className="font-serif text-[21px] leading-none text-ink">{r.price}</span>}
                <button onClick={() => { setEditing(r); setAdding(false); }}
                  className="btn border border-rule text-[12px] text-ink-2">Edit</button>
                <form action={deleteRowAction}>
                  <input type="hidden" name="listingId" value={listingId} />
                  <input type="hidden" name="rowId" value={r.id} />
                  <button className="btn border border-rule text-[12px] text-[#B4441F]">Delete</button>
                </form>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

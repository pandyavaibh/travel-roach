import Link from 'next/link';
import { notFound } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { db, listings, cities, states } from '@/db';
import { requireOwner } from '@/lib/auth';

const TABS: [string, string][] = [
  ['Details', 'details'],
  ['Photos', 'photos'],
  ['Rows', 'rows'],
  ['Reviews', 'reviews'],
  ['Enquiries', 'enquiries'],
];

const ROW_LABEL: Record<string, string> = {
  hotels: 'Rooms & rates', restaurants: 'Menu & prices', 'travel-agents': 'Tours & packages',
};

export default async function ListingLayout({
  children, params,
}: { children: React.ReactNode; params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = await requireOwner();

  const [l] = await db
    .select({
      id: listings.id, name: listings.name, kind: listings.kind, slug: listings.slug,
      ownerId: listings.ownerId, city: cities.slug, state: states.slug,
    })
    .from(listings)
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(listings.id, Number(id)))
    .limit(1);

  if (!l) notFound();
  // Admins can open any listing; owners only their own.
  if (user.role !== 'admin' && l.ownerId !== user.id) notFound();

  const publicHref = `/${l.state}/${l.city}/${l.kind}/${l.slug}`;

  return (
    <>
      <div className="border-b border-rule bg-white">
        <div className="shell pt-[clamp(18px,2.4vw,30px)]">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div className="min-w-0">
              <Link href="/portal" className="meta hover:text-orange">&larr; All listings</Link>
              <h1 className="m-0 mt-2 font-serif text-[clamp(24px,3.2vw,36px)] leading-tight tracking-[-.02em]">
                {l.name}
              </h1>
            </div>
            <Link href={publicHref} className="btn-outline">View public page</Link>
          </div>

          <nav className="rail mt-5 flex gap-2 overflow-x-auto pb-3">
            {TABS.map(([label, seg]) => (
              <Link key={seg} href={`/portal/${l.id}/${seg}`} className="pill pill-off">
                {seg === 'rows' ? ROW_LABEL[l.kind] ?? label : label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
      {children}
    </>
  );
}

import { desc, eq } from 'drizzle-orm';
import { db, enquiries, listings } from '@/db';
import { requireOwner } from '@/lib/auth';
import { setEnquiryStatusAction } from '@/app/portal/actions';

export const dynamic = 'force-dynamic';

const TONE: Record<string, string> = {
  new: 'bg-orange text-white',
  read: 'border border-rule text-ink-2',
  replied: 'bg-trust text-white',
  spam: 'border border-rule text-muted',
};

export default async function EnquiriesPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireOwner();
  const listingId = Number(id);

  const [l] = await db.select({ views: listings.viewsThisMonth, email: listings.email })
    .from(listings).where(eq(listings.id, listingId)).limit(1);

  const rows = await db.select().from(enquiries)
    .where(eq(enquiries.listingId, listingId))
    .orderBy(desc(enquiries.createdAt))
    .limit(100);

  return (
    <main className="shell py-[clamp(22px,3vw,40px)]">
      <div className="flex flex-wrap items-end justify-between gap-5">
        <p className="m-0 max-w-[58ch] text-[15px] leading-relaxed text-ink-3">
          Enquiries arrive by email as well{l?.email ? ` — currently to ${l.email}` : ''}.
          This is the record, so nothing gets lost in an inbox.
        </p>
        <div className="text-right">
          <div className="font-serif text-[28px] leading-none text-ink">{l?.views ?? 0}</div>
          <div className="meta mt-1.5">profile views this month</div>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="mt-7 rounded-card border border-rule bg-white p-[clamp(24px,3.4vw,44px)] text-center">
          <h2 className="m-0 font-serif text-[24px] leading-tight">No enquiries yet</h2>
          <p className="mx-auto mt-3 max-w-[48ch] text-[15px] leading-relaxed text-muted-2">
            Listings with photos and filled-in prices get contacted more often than those without.
            That is the whole trick.
          </p>
        </div>
      ) : (
        <div className="mt-7 flex flex-col gap-3">
          {rows.map((e) => (
            <article key={e.id} className="rounded-card border border-rule bg-white p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <div className="min-w-0">
                  <span className="text-[15px] font-semibold text-ink">{e.name}</span>
                  <span className={`ml-2.5 inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${TONE[e.status ?? 'new']}`}>
                    {e.status}
                  </span>
                </div>
                <span className="meta">
                  {e.createdAt ? new Date(e.createdAt).toLocaleDateString('en-GB', {
                    day: 'numeric', month: 'short', year: 'numeric',
                  }) : ''}
                </span>
              </div>

              <div className="mt-2.5 flex flex-wrap gap-x-5 gap-y-1 text-[13px] text-ink-3">
                <a href={`mailto:${e.email}`} className="font-medium hover:text-orange">{e.email}</a>
                {e.phone && <a href={`tel:${e.phone}`} className="hover:text-orange">{e.phone}</a>}
                {e.travelDates && <span className="text-muted-2">Dates: {e.travelDates}</span>}
              </div>

              {e.message && (
                <p className="mt-3 rounded-card bg-paper p-4 text-[14px] leading-[1.65] text-ink-3">
                  {e.message}
                </p>
              )}

              <div className="mt-3.5 flex flex-wrap gap-2">
                <a href={`mailto:${e.email}`} className="btn-primary">Reply by email</a>
                {(['read', 'replied', 'spam'] as const)
                  .filter((s) => s !== e.status)
                  .map((s) => (
                    <form key={s} action={setEnquiryStatusAction}>
                      <input type="hidden" name="listingId" value={listingId} />
                      <input type="hidden" name="enquiryId" value={e.id} />
                      <input type="hidden" name="status" value={s} />
                      <button className="btn border border-rule text-[12px] text-ink-2">
                        Mark {s}
                      </button>
                    </form>
                  ))}
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}

import { and, eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { db, listings, media } from '@/db';
import { requireOwner } from '@/lib/auth';
import { QUOTA } from '@/lib/upload';
import PhotoManager from './PhotoManager';

export const dynamic = 'force-dynamic';

export default async function PhotosPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireOwner();
  const listingId = Number(id);

  const [l] = await db.select({ heroMediaId: listings.heroMediaId, kind: listings.kind })
    .from(listings).where(eq(listings.id, listingId)).limit(1);
  if (!l) notFound();

  const photos = await db.select({
    id: media.id, path: media.path, thumbPath: media.thumbPath,
    filename: media.filename, bytes: media.bytes,
  })
    .from(media)
    .where(and(eq(media.ownerKind, 'listing'), eq(media.ownerId, listingId)))
    .orderBy(media.sortOrder, media.id);

  const hint = l.kind === 'hotels'
    ? 'Rooms, bathrooms, breakfast, the view from the window, and the entrance so people can find you.'
    : l.kind === 'restaurants'
      ? 'The room, the food as it actually arrives, and the menu board if you have one.'
      : 'Trips you have run, groups you have hosted, and your vehicles.';

  return (
    <main className="shell py-[clamp(22px,3vw,40px)]">
      <p className="m-0 max-w-[62ch] text-[15px] leading-relaxed text-ink-3">{hint}</p>
      <p className="m-0 mt-2 text-[13px] text-muted-2">
        Up to {QUOTA.owner} photos. Each is resized and converted automatically — upload the
        original and we handle the rest.
      </p>
      <PhotoManager
        listingId={listingId}
        heroId={l.heroMediaId}
        photos={photos}
        max={QUOTA.owner}
      />
    </main>
  );
}

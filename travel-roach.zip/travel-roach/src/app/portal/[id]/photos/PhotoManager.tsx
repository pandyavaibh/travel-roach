'use client';

import { useState, useTransition } from 'react';
import {
  uploadListingPhotoAction, deleteListingPhotoAction, setHeroPhotoAction,
} from '@/app/portal/actions';

type Photo = { id: number; path: string; thumbPath: string | null; filename: string; bytes: number };

export default function PhotoManager({ listingId, heroId, photos, max }: {
  listingId: number; heroId: number | null; photos: Photo[]; max: number;
}) {
  const [pending, start] = useTransition();
  const [error, setError] = useState('');

  const onFiles = (files: FileList | null) => {
    if (!files?.length) return;
    setError('');
    start(async () => {
      for (const file of Array.from(files)) {
        const fd = new FormData();
        fd.set('listingId', String(listingId));
        fd.set('file', file);
        const res = await uploadListingPhotoAction(fd);
        if (res?.error) { setError(res.error); break; }
      }
    });
  };

  const full = photos.length >= max;

  return (
    <>
      {full ? (
        <div className="mt-6 rounded-card border border-sand-rule bg-sand p-5">
          <p className="m-0 text-[14px] leading-relaxed text-ink-3">
            You have {max} photos, which is the limit. Delete one to add another.
          </p>
        </div>
      ) : (
        <label
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); onFiles(e.dataTransfer.files); }}
          className="mt-6 flex cursor-pointer flex-col items-center justify-center gap-2 rounded-card border-2 border-dashed border-rule-3 bg-white p-[clamp(24px,4vw,44px)] hover:border-orange"
        >
          <span className="font-serif text-[20px] text-ink">
            {pending ? 'Uploading…' : 'Drop photos here'}
          </span>
          <span className="meta">
            or click to choose · {photos.length} of {max} used
          </span>
          <input type="file" accept="image/*" multiple className="hidden"
            onChange={(e) => onFiles(e.target.files)} />
        </label>
      )}

      {error && <p className="mt-3 text-[13px] text-[#B4441F]">{error}</p>}

      {photos.length === 0 ? (
        <p className="mt-7 text-[15px] text-muted-2">No photos yet.</p>
      ) : (
        <div className="mt-7 grid gap-[clamp(10px,1.2vw,16px)] [grid-template-columns:repeat(auto-fill,minmax(160px,1fr))]">
          {photos.map((p) => {
            const isHero = p.id === heroId;
            return (
              <div key={p.id} className={`overflow-hidden rounded-card border bg-white ${isHero ? 'border-orange' : 'border-rule'}`}>
                <div className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={p.thumbPath || p.path} alt="" loading="lazy"
                    className="block aspect-square w-full object-cover" />
                  {isHero && (
                    <span className="absolute left-2 top-2 rounded-full bg-orange px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] text-white">
                      Header
                    </span>
                  )}
                </div>
                <div className="flex flex-wrap gap-1.5 p-2.5">
                  {!isHero && (
                    <form action={setHeroPhotoAction} className="flex-1">
                      <input type="hidden" name="listingId" value={listingId} />
                      <input type="hidden" name="mediaId" value={p.id} />
                      <button className="min-h-[34px] w-full rounded-full border border-rule text-[11px] font-semibold text-ink-2 hover:border-ink">
                        Make header
                      </button>
                    </form>
                  )}
                  <form action={deleteListingPhotoAction} className={isHero ? 'flex-1' : ''}>
                    <input type="hidden" name="listingId" value={listingId} />
                    <input type="hidden" name="mediaId" value={p.id} />
                    <button className="min-h-[34px] w-full rounded-full border border-rule px-3 text-[11px] font-semibold text-[#B4441F] hover:border-[#B4441F]">
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

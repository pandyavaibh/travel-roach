import { and, desc, eq } from 'drizzle-orm';
import { db, reviews, users, listings } from '@/db';
import { requireOwner } from '@/lib/auth';
import { replyToReviewAction } from '@/app/portal/actions';
import { Badge } from '@/components/ui';

export const dynamic = 'force-dynamic';

export default async function ReviewsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await requireOwner();
  const listingId = Number(id);

  const rows = await db
    .select({
      id: reviews.id, rating: reviews.rating, body: reviews.body,
      tripLabel: reviews.tripLabel, verifiedBooking: reviews.verifiedBooking,
      ownerReply: reviews.ownerReply, createdAt: reviews.createdAt,
      author: users.name,
    })
    .from(reviews)
    .innerJoin(users, eq(reviews.userId, users.id))
    .where(and(eq(reviews.listingId, listingId), eq(reviews.status, 'published')))
    .orderBy(desc(reviews.createdAt));

  const unreplied = rows.filter((r) => !r.ownerReply).length;

  return (
    <main className="shell py-[clamp(22px,3vw,40px)]">
      <p className="m-0 max-w-[64ch] text-[15px] leading-relaxed text-ink-3">
        {rows.length === 0
          ? 'No reviews yet. They come from travellers who contacted you through this site.'
          : unreplied > 0
            ? `${unreplied} of ${rows.length} ${unreplied === 1 ? 'review has' : 'reviews have'} no reply. A short, specific reply does more for the next reader than the review itself.`
            : `${rows.length} ${rows.length === 1 ? 'review' : 'reviews'}, all replied to.`}
      </p>
      <p className="m-0 mt-2 text-[13px] leading-relaxed text-muted-2">
        You can reply to any review. You cannot delete one — if a review breaks the rules,
        report it and a person will look.
      </p>

      <div className="mt-7 flex flex-col gap-3.5">
        {rows.map((r) => (
          <article key={r.id} className="rounded-card border border-rule bg-white p-[clamp(18px,2.4vw,26px)]">
            <div className="flex flex-wrap items-baseline justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="text-[15px] font-semibold text-ink">{r.author}</span>
                {r.verifiedBooking && <Badge>Verified booking</Badge>}
              </div>
              <span className="meta">
                {r.rating}.0 · {r.createdAt ? new Date(r.createdAt).toLocaleDateString('en-GB') : ''}
              </span>
            </div>

            {r.tripLabel && <div className="meta mt-2">{r.tripLabel}</div>}
            <p className="mt-3 text-[14px] leading-[1.65] text-ink-3">{r.body}</p>

            {r.ownerReply ? (
              <div className="mt-4 rounded-card border-l-2 border-orange bg-paper p-4">
                <div className="label">Your reply</div>
                <p className="mt-2 text-[13px] leading-relaxed text-ink-3">{r.ownerReply}</p>
              </div>
            ) : (
              <form action={replyToReviewAction} className="mt-4">
                <input type="hidden" name="reviewId" value={r.id} />
                <input type="hidden" name="listingId" value={listingId} />
                <textarea name="reply" rows={2} required
                  placeholder="Reply publicly. Specific beats apologetic."
                  className="w-full resize-y rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange" />
                <button className="btn-primary mt-2.5">Post reply</button>
              </form>
            )}
          </article>
        ))}
      </div>
    </main>
  );
}

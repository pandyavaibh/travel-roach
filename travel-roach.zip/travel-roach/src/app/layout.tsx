import type { Metadata } from 'next';
import { Newsreader, Plus_Jakarta_Sans } from 'next/font/google';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import TabBar from '@/components/TabBar';
import TypeSwitch from '@/components/TypeSwitch';
import { SITE } from '@/lib/site';
import './globals.css';

const serif = Newsreader({
  subsets: ['latin'], weight: ['300', '400', '500'], style: ['normal', 'italic'],
  variable: '--font-serif', display: 'swap',
});
const sans = Plus_Jakarta_Sans({
  subsets: ['latin'], weight: ['400', '500', '600', '700', '800'],
  variable: '--font-sans', display: 'swap',
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: SITE.name + ' — India travel guides', template: '%s | ' + SITE.name },
  description: 'Guides written on the ground, state by state and city by city, with verified travel agents, hotels and restaurants. No booking fees.',
  openGraph: { siteName: SITE.name, type: 'website' },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-type="serif" className={serif.variable + ' ' + sans.variable}>
      <body className="tabbar-gap">
        <Header />
        {children}
        <Footer />
        <TabBar />
        <TypeSwitch />
      </body>
    </html>
  );
}

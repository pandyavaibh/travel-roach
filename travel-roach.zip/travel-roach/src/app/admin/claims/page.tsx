import Link from 'next/link';
import { desc, eq } from 'drizzle-orm';
import { db, claims, listings, users, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { Badge } from '@/components/ui';
import { decideClaimAction } from './actions';

export const dynamic = 'force-dynamic';

export default async function ClaimsPage({ searchParams }: {
  searchParams: Promise<{ status?: string }>;
}) {
  await requireStaff();
  const { status = 'pending' } = await searchParams;

  const rows = await db
    .select({
      id: claims.id, status: claims.status, method: claims.method,
      evidence: claims.evidence, createdAt: claims.createdAt,
      listingId: listings.id, listing: listings.name, listingSlug: listings.slug,
      kind: listings.kind, website: listings.website, currentOwner: listings.ownerId,
      city: cities.slug, state: states.slug,
      userName: users.name, userEmail: users.email, userId: users.id,
    })
    .from(claims)
    .innerJoin(listings, eq(claims.listingId, listings.id))
    .innerJoin(users, eq(claims.userId, users.id))
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(desc(claims.createdAt))
    .limit(100);

  const filtered = status === 'all' ? rows : rows.filter((r) => r.status === status);
  const counts = {
    pending: rows.filter((r) => r.status === 'pending').length,
    approved: rows.filter((r) => r.status === 'approved').length,
    rejected: rows.filter((r) => r.status === 'rejected').length,
  };

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">Admin</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Claims</h1>
      <p className="mt-3.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
        Claims whose email domain matched the listing website were approved automatically.
        These are the ones that need a person: a free email address, or no website on file.
      </p>

      <div className="rail mt-6 flex gap-2 overflow-x-auto">
        {([['pending', counts.pending], ['approved', counts.approved], ['rejected', counts.rejected], ['all', rows.length]] as const).map(([s, n]) => (
          <Link key={s} href={`/admin/claims?status=${s}`}
            className={`pill ${status === s ? 'pill-on' : 'pill-off'}`}>
            {s}<span className="opacity-60">{n}</span>
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="mt-8 text-[15px] text-muted-2">Nothing {status === 'all' ? 'here' : status}.</p>
      ) : (
        <div className="mt-7 flex flex-col gap-3.5">
          {filtered.map((c) => (
            <article key={c.id} className="rounded-card border border-rule bg-white p-[clamp(18px,2.4vw,26px)]">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <Link href={`/${c.state}/${c.city}/${c.kind}/${c.listingSlug}`}
                      className="font-serif text-[22px] leading-tight text-ink hover:text-orange">
                      {c.listing}
                    </Link>
                    {c.status === 'pending' && <Badge tone="sand">Needs review</Badge>}
                    {c.status === 'approved' && <Badge>Approved</Badge>}
                    {c.status === 'rejected' && <Badge tone="ink">Rejected</Badge>}
                  </div>
                  <div className="meta mt-2">
                    {c.city} · {c.kind}
                    {c.currentOwner && c.currentOwner !== c.userId && ' · already has a different owner'}
                  </div>
                </div>
                <span className="meta">
                  {c.createdAt ? new Date(c.createdAt).toLocaleDateString('en-GB') : ''}
                </span>
              </div>

              <div className="mt-4 grid gap-4 [grid-template-columns:repeat(auto-fit,minmax(200px,1fr))]">
                <div>
                  <div className="label">Claimant</div>
                  <div className="mt-2 text-[14px] font-medium text-ink">{c.userName}</div>
                  <a href={`mailto:${c.userEmail}`} className="mt-1 block text-[13px] text-ink-3 hover:text-orange">
                    {c.userEmail}
                  </a>
                </div>
                <div>
                  <div className="label">Listing website</div>
                  <div className="mt-2 text-[13px] text-ink-3">
                    {c.website
                      ? <a href={c.website} target="_blank" rel="noopener noreferrer" className="hover:text-orange">{c.website}</a>
                      : <span className="text-muted-2">None on file</span>}
                  </div>
                </div>
              </div>

              {c.evidence && (
                <div className="mt-4">
                  <div className="label">What they told us</div>
                  <p className="mt-2 rounded-card bg-paper p-4 text-[14px] leading-[1.65] text-ink-3">
                    {c.evidence}
                  </p>
                </div>
              )}

              {c.status === 'pending' && (
                <div className="mt-5 flex flex-wrap gap-2">
                  <form action={decideClaimAction}>
                    <input type="hidden" name="claimId" value={c.id} />
                    <input type="hidden" name="decision" value="approve" />
                    <button className="btn-primary">Approve — they manage it</button>
                  </form>
                  <form action={decideClaimAction}>
                    <input type="hidden" name="claimId" value={c.id} />
                    <input type="hidden" name="decision" value="reject" />
                    <button className="btn border border-rule text-[#B4441F]">Reject</button>
                  </form>
                  <span className="flex-1" />
                  <Link href={`/portal/${c.listingId}/details`} className="btn-outline">
                    Open listing
                  </Link>
                </div>
              )}
            </article>
          ))}
        </div>
      )}
    </main>
  );
}

'use server';

import { revalidatePath } from 'next/cache';
import { eq } from 'drizzle-orm';
import { db, claims, listings, users } from '@/db';
import { requireStaff } from '@/lib/auth';
import { mailClaimApproved } from '@/lib/email';

const SITE = () => process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000';

export async function decideClaimAction(fd: FormData) {
  const staff = await requireStaff();
  const claimId = Number(fd.get('claimId'));
  const approve = String(fd.get('decision')) === 'approve';

  const [c] = await db.select().from(claims).where(eq(claims.id, claimId)).limit(1);
  if (!c || c.status !== 'pending') return;

  await db.update(claims).set({
    status: approve ? 'approved' : 'rejected',
    reviewedBy: staff.id,
    reviewedAt: new Date(),
  }).where(eq(claims.id, claimId));

  if (approve) {
    // Ownership and the role change happen together, or the owner cannot log in
    // to the thing they now own.
    await db.update(listings).set({ ownerId: c.userId }).where(eq(listings.id, c.listingId));
    await db.update(users).set({ role: 'owner' }).where(eq(users.id, c.userId));

    const [l] = await db.select({ name: listings.name }).from(listings)
      .where(eq(listings.id, c.listingId)).limit(1);
    const [u] = await db.select({ email: users.email }).from(users)
      .where(eq(users.id, c.userId)).limit(1);
    if (l && u) await mailClaimApproved(u.email, l.name, `${SITE()}/portal`);
  }

  revalidatePath('/admin/claims');
  revalidatePath('/admin');
}

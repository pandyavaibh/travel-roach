import Link from 'next/link';
import { asc, eq, sql } from 'drizzle-orm';
import { db, listings, users, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { inr } from '@/lib/site';
import { Badge } from '@/components/ui';
import { setVerifiedAction, setListingStatusAction, releaseOwnerAction } from './actions';

export const dynamic = 'force-dynamic';

const KIND_LABEL: Record<string, string> = {
  'travel-agents': 'Agent', hotels: 'Hotel', restaurants: 'Restaurant',
};

export default async function AdminListingsPage({ searchParams }: {
  searchParams: Promise<{ kind?: string; filter?: string }>;
}) {
  await requireStaff();
  const { kind = 'all', filter = 'all' } = await searchParams;

  const rows = await db
    .select({
      id: listings.id, name: listings.name, slug: listings.slug, kind: listings.kind,
      verified: listings.verified, registration: listings.registration,
      status: listings.status, priceFrom: listings.priceFrom,
      rating: listings.ratingCached, reviewCount: listings.reviewCountCached,
      views: listings.viewsThisMonth,
      ownerId: listings.ownerId, ownerName: users.name, ownerEmail: users.email,
      city: cities.slug, cityName: cities.name, state: states.slug,
    })
    .from(listings)
    .leftJoin(users, eq(listings.ownerId, users.id))
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(cities.name), asc(listings.kind), asc(listings.name))
    .limit(400);

  let shown = kind === 'all' ? rows : rows.filter((r) => r.kind === kind);
  if (filter === 'unverified') shown = shown.filter((r) => !r.verified);
  if (filter === 'unclaimed') shown = shown.filter((r) => !r.ownerId);
  if (filter === 'claimed') shown = shown.filter((r) => !!r.ownerId);

  const verified = rows.filter((r) => r.verified).length;
  const claimed = rows.filter((r) => r.ownerId).length;

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">Admin</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Listings</h1>
      <p className="mt-3.5 max-w-[64ch] text-[15px] leading-relaxed text-muted-2">
        {rows.length} in the database. {verified} verified, {claimed} claimed by an owner.
        Verification is a document check, and it does not move anything up the page.
      </p>

      <div className="rail mt-6 flex gap-2 overflow-x-auto">
        {([['all', 'All kinds'], ['travel-agents', 'Agents'], ['hotels', 'Hotels'], ['restaurants', 'Restaurants']] as const).map(([k, label]) => (
          <Link key={k} href={`/admin/listings?kind=${k}&filter=${filter}`}
            className={`pill ${kind === k ? 'pill-on' : 'pill-off'}`}>{label}</Link>
        ))}
      </div>
      <div className="rail mt-2 flex gap-2 overflow-x-auto">
        {([['all', 'Everything'], ['unverified', 'Unverified'], ['unclaimed', 'No owner'], ['claimed', 'Has owner']] as const).map(([fl, label]) => (
          <Link key={fl} href={`/admin/listings?kind=${kind}&filter=${fl}`}
            className={`pill ${filter === fl ? 'pill-on' : 'pill-off'}`}>{label}</Link>
        ))}
      </div>

      <div className="meta mt-5">Showing {shown.length}</div>

      <div className="hair mt-3 [grid-template-columns:1fr]">
        {shown.map((l) => (
          <div key={l.id} className="bg-white p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2.5">
                  <Link href={`/${l.state}/${l.city}/${l.kind}/${l.slug}`}
                    className="font-serif text-[20px] leading-tight text-ink hover:text-orange">
                    {l.name}
                  </Link>
                  {l.verified && <Badge>Verified</Badge>}
                  {l.status === 'draft' && <Badge tone="sand">Draft</Badge>}
                </div>
                <div className="meta mt-1.5">
                  {KIND_LABEL[l.kind]} · {l.cityName}
                  {Number(l.reviewCount) > 0 && ` · ${Number(l.rating).toFixed(1)} from ${l.reviewCount}`}
                  {l.priceFrom ? ` · from ${inr(l.priceFrom)}` : ''}
                  {` · ${l.views ?? 0} views`}
                </div>
                <div className="mt-1.5 text-[12px] text-muted-2">
                  {l.ownerName
                    ? <>Managed by {l.ownerName} · {l.ownerEmail}</>
                    : <span className="text-orange-deep">No owner account</span>}
                  {l.registration && ` · ${l.registration}`}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <form action={setVerifiedAction} className="flex items-center gap-1.5">
                  <input type="hidden" name="listingId" value={l.id} />
                  <input type="hidden" name="verify" value={l.verified ? 'false' : 'true'} />
                  {!l.verified && (
                    <input name="registration" placeholder="Reg. / licence no."
                      className="min-h-[38px] w-[150px] rounded-full border border-rule bg-paper px-3.5 text-[12px] outline-none focus:border-orange" />
                  )}
                  <button className={l.verified
                    ? 'btn border border-rule text-[12px] text-ink-2'
                    : 'btn bg-trust text-[12px] text-white'}>
                    {l.verified ? 'Un-verify' : 'Verify'}
                  </button>
                </form>

                <form action={setListingStatusAction}>
                  <input type="hidden" name="listingId" value={l.id} />
                  <input type="hidden" name="status" value={l.status === 'published' ? 'draft' : 'published'} />
                  <button className="btn border border-rule text-[12px] text-ink-2">
                    {l.status === 'published' ? 'Unpublish' : 'Publish'}
                  </button>
                </form>

                {l.ownerId && (
                  <>
                    <Link href={`/portal/${l.id}/details`} className="btn border border-rule text-[12px] text-ink-2">
                      Open
                    </Link>
                    <form action={releaseOwnerAction}>
                      <input type="hidden" name="listingId" value={l.id} />
                      <button className="btn border border-rule text-[12px] text-[#B4441F]">
                        Release
                      </button>
                    </form>
                  </>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}

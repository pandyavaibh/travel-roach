'use server';

import { revalidatePath } from 'next/cache';
import { eq } from 'drizzle-orm';
import { db, listings, users } from '@/db';
import { requireStaff } from '@/lib/auth';

export async function setVerifiedAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('listingId'));
  const verify = String(fd.get('verify')) === 'true';
  const registration = String(fd.get('registration') ?? '').trim().slice(0, 200);

  await db.update(listings).set({
    verified: verify,
    verifiedAt: verify ? new Date() : null,
    // The badge means nothing without a record of what was checked and when.
    registration: verify
      ? (registration || `Checked ${new Date().toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}`)
      : null,
  }).where(eq(listings.id, id));

  revalidatePath('/admin/listings');
}

export async function setListingStatusAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('listingId'));
  const status = String(fd.get('status'));
  if (!['draft', 'published'].includes(status)) return;
  await db.update(listings).set({ status: status as 'draft' | 'published' })
    .where(eq(listings.id, id));
  revalidatePath('/admin/listings');
}

/** Removes the owner link without deleting the account or the listing. */
export async function releaseOwnerAction(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('listingId'));
  await db.update(listings).set({ ownerId: null }).where(eq(listings.id, id));
  revalidatePath('/admin/listings');
}

import Link from 'next/link';
import { asc, eq, sql } from 'drizzle-orm';
import { db, cities, states, posts } from '@/db';
import { requireStaff } from '@/lib/auth';
import { toggleCityPublished, toggleCityNoindex } from '../posts/actions';

export const dynamic = 'force-dynamic';

export default async function CitiesPage() {
  await requireStaff();

  const rows = await db
    .select({
      id: cities.id, slug: cities.slug, name: cities.name,
      published: cities.published, noindex: cities.noindex,
      stateName: states.name, stateSlug: states.slug,
      livePosts: sql<number>`(
        select count(*) from posts
        where posts.city_id = ${cities.id} and posts.status = 'published'
      )::int`,
    })
    .from(cities)
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(states.name), asc(cities.name));

  const live = rows.filter((r) => r.published);
  const indexed = live.filter((r) => !r.noindex);

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">Admin</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Cities</h1>
      <p className="mt-3.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
        A hidden city does not appear anywhere on the public site. A live city appears, but stays out of search
        engines until you clear its noindex flag — so you can publish, read it back, then let Google have it.
      </p>

      <div className="hair mt-7 [grid-template-columns:repeat(auto-fit,minmax(170px,1fr))]">
        {([['Cities', rows.length], ['Live', live.length], ['Indexed', indexed.length]] as [string, number][])
          .map(([label, n]) => (
            <div key={label} className="bg-white p-5 pb-6">
              <div className="font-serif text-[clamp(28px,3.2vw,40px)] leading-none text-ink">{n}</div>
              <div className="meta mt-3">{label}</div>
            </div>
          ))}
      </div>

      <div className="hair mt-7 [grid-template-columns:1fr]">
        {rows.map((c) => (
          <div key={c.id} className="flex flex-wrap items-center justify-between gap-x-5 gap-y-3 bg-white px-5 py-4">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2.5">
                <span className="font-serif text-[19px] leading-tight text-ink">{c.name}</span>
                <span className="meta">{c.stateName}</span>
              </div>
              <div className="meta mt-1.5">
                {c.livePosts > 0
                  ? `${c.livePosts} published ${c.livePosts === 1 ? 'post' : 'posts'}`
                  : 'No posts — pages fall back to generated scaffolding'}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${
                c.published ? 'bg-trust text-white' : 'bg-sand text-orange-deep'
              }`}>{c.published ? 'Live' : 'Hidden'}</span>

              <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${
                c.noindex ? 'bg-night text-paper' : 'border border-rule text-muted-2'
              }`}>{c.noindex ? 'Noindex' : 'Indexed'}</span>

              {c.published && (
                <a href={`/${c.stateSlug}/${c.slug}`} target="_blank" rel="noopener noreferrer"
                  className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink-2">View</a>
              )}

              <form action={toggleCityPublished}>
                <input type="hidden" name="id" value={c.id} />
                <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink">
                  {c.published ? 'Hide' : 'Publish'}
                </button>
              </form>

              <form action={toggleCityNoindex}>
                <input type="hidden" name="id" value={c.id} />
                <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink">
                  {c.noindex ? 'Allow indexing' : 'Set noindex'}
                </button>
              </form>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-7 text-[13px] text-muted-2">
        Writing is on <Link href="/admin/posts" className="font-semibold text-ink hover:text-orange">Posts</Link>.
      </p>
    </main>
  );
}

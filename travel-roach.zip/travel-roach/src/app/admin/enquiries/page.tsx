import Link from 'next/link';
import { desc, eq, sql } from 'drizzle-orm';
import { db, enquiries, listings, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';

export const dynamic = 'force-dynamic';

const TONE: Record<string, string> = {
  new: 'bg-orange text-white',
  read: 'border border-rule text-ink-2',
  replied: 'bg-trust text-white',
  spam: 'border border-rule text-muted',
};

export default async function AdminEnquiriesPage() {
  await requireStaff();

  const rows = await db
    .select({
      id: enquiries.id, name: enquiries.name, email: enquiries.email,
      phone: enquiries.phone, travelDates: enquiries.travelDates,
      message: enquiries.message, status: enquiries.status,
      createdAt: enquiries.createdAt, sourcePage: enquiries.sourcePage,
      listing: listings.name, listingSlug: listings.slug, kind: listings.kind,
      ownerId: listings.ownerId, city: cities.slug, state: states.slug,
    })
    .from(enquiries)
    .leftJoin(listings, eq(enquiries.listingId, listings.id))
    .leftJoin(cities, eq(listings.cityId, cities.id))
    .leftJoin(states, eq(cities.stateId, states.id))
    .orderBy(desc(enquiries.createdAt))
    .limit(120);

  const [week] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(enquiries)
    .where(sql`created_at > now() - interval '7 days'`);

  const orphaned = rows.filter((r) => r.listing && !r.ownerId).length;

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Enquiries</h1>
        </div>
        <div className="text-right">
          <div className="font-serif text-[30px] leading-none text-ink">{week?.n ?? 0}</div>
          <div className="meta mt-1.5">in the last 7 days</div>
        </div>
      </div>

      <p className="mt-3.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
        Every enquiry across the site. Owners see their own in the portal; this is the
        whole picture, and the number that tells you whether the directory is working.
      </p>

      {orphaned > 0 && (
        <div className="mt-5 rounded-card border border-sand-rule bg-sand p-[18px]">
          <p className="m-0 text-[13px] leading-relaxed text-ink-3">
            <strong className="font-semibold">{orphaned}</strong> of these went to listings with no
            owner account, so nobody logged in has seen them. Those are the businesses worth calling.
          </p>
        </div>
      )}

      {rows.length === 0 ? (
        <p className="mt-8 text-[15px] text-muted-2">No enquiries yet.</p>
      ) : (
        <div className="mt-7 flex flex-col gap-3">
          {rows.map((e) => (
            <article key={e.id} className="rounded-card border border-rule bg-white p-5">
              <div className="flex flex-wrap items-baseline justify-between gap-3">
                <div className="min-w-0">
                  <span className="text-[15px] font-semibold text-ink">{e.name}</span>
                  <span className={`ml-2.5 inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${TONE[e.status ?? 'new']}`}>
                    {e.status}
                  </span>
                  {e.listing && !e.ownerId && (
                    <span className="ml-2 text-[11px] font-semibold text-orange-deep">unclaimed listing</span>
                  )}
                </div>
                <span className="meta">
                  {e.createdAt ? new Date(e.createdAt).toLocaleDateString('en-GB', {
                    day: 'numeric', month: 'short',
                  }) : ''}
                </span>
              </div>

              <div className="mt-2 text-[13px] text-muted-2">
                {e.listing && e.state ? (
                  <Link href={`/${e.state}/${e.city}/${e.kind}/${e.listingSlug}`} className="font-medium text-ink-3 hover:text-orange">
                    {e.listing}
                  </Link>
                ) : (
                  <span>{e.sourcePage ?? 'General enquiry'}</span>
                )}
              </div>

              <div className="mt-2.5 flex flex-wrap gap-x-5 gap-y-1 text-[13px] text-ink-3">
                <a href={`mailto:${e.email}`} className="font-medium hover:text-orange">{e.email}</a>
                {e.phone && <span>{e.phone}</span>}
                {e.travelDates && <span className="text-muted-2">Dates: {e.travelDates}</span>}
              </div>

              {e.message && (
                <p className="mt-3 rounded-card bg-paper p-4 text-[14px] leading-[1.6] text-ink-3">
                  {e.message}
                </p>
              )}
            </article>
          ))}
        </div>
      )}
    </main>
  );
}

import Link from 'next/link';
import { desc, eq } from 'drizzle-orm';
import { db, reviews, listings, users, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { Badge } from '@/components/ui';
import { setReviewStatusAction } from '@/app/review-actions';

export const dynamic = 'force-dynamic';

export default async function AdminReviewsPage({ searchParams }: {
  searchParams: Promise<{ status?: string }>;
}) {
  await requireStaff();
  const { status = 'reported' } = await searchParams;

  const rows = await db
    .select({
      id: reviews.id, rating: reviews.rating, body: reviews.body,
      tripLabel: reviews.tripLabel, verifiedBooking: reviews.verifiedBooking,
      ownerReply: reviews.ownerReply, status: reviews.status, createdAt: reviews.createdAt,
      author: users.name, authorEmail: users.email,
      listing: listings.name, listingSlug: listings.slug, kind: listings.kind,
      city: cities.slug, state: states.slug,
    })
    .from(reviews)
    .innerJoin(users, eq(reviews.userId, users.id))
    .innerJoin(listings, eq(reviews.listingId, listings.id))
    .innerJoin(cities, eq(listings.cityId, cities.id))
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(desc(reviews.createdAt))
    .limit(150);

  const filtered = status === 'all' ? rows : rows.filter((r) => r.status === status);
  const counts = {
    reported: rows.filter((r) => r.status === 'reported').length,
    published: rows.filter((r) => r.status === 'published').length,
    hidden: rows.filter((r) => r.status === 'hidden').length,
  };

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">Admin</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Reviews</h1>
      <p className="mt-3.5 max-w-[62ch] text-[15px] leading-relaxed text-muted-2">
        Reviews publish immediately. This is where reported ones land. Hiding a review
        recalculates the listing&rsquo;s rating straight away.
      </p>

      <div className="rail mt-6 flex gap-2 overflow-x-auto">
        {([['reported', counts.reported], ['published', counts.published], ['hidden', counts.hidden], ['all', rows.length]] as const).map(([s, n]) => (
          <Link key={s} href={`/admin/reviews?status=${s}`}
            className={`pill ${status === s ? 'pill-on' : 'pill-off'}`}>
            {s}<span className="opacity-60">{n}</span>
          </Link>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="mt-8 text-[15px] text-muted-2">
          {status === 'reported' ? 'Nothing reported. Good.' : `No ${status} reviews.`}
        </p>
      ) : (
        <div className="mt-7 flex flex-col gap-3.5">
          {filtered.map((r) => (
            <article key={r.id} className="rounded-card border border-rule bg-white p-[clamp(18px,2.4vw,26px)]">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div className="min-w-0">
                  <Link href={`/${r.state}/${r.city}/${r.kind}/${r.listingSlug}`}
                    className="font-serif text-[20px] leading-tight text-ink hover:text-orange">
                    {r.listing}
                  </Link>
                  <div className="meta mt-1.5">{r.city} · {r.kind}</div>
                </div>
                <div className="flex flex-wrap items-center gap-2.5">
                  {r.status === 'reported' && <Badge tone="sand">Reported</Badge>}
                  {r.status === 'hidden' && <Badge tone="ink">Hidden</Badge>}
                  {r.verifiedBooking && <Badge>Verified booking</Badge>}
                  <span className="meta">
                    {r.rating}.0 · {r.createdAt ? new Date(r.createdAt).toLocaleDateString('en-GB') : ''}
                  </span>
                </div>
              </div>

              <div className="mt-3.5 text-[13px] text-muted-2">
                {r.author} · <a href={`mailto:${r.authorEmail}`} className="hover:text-orange">{r.authorEmail}</a>
                {r.tripLabel && ` · ${r.tripLabel}`}
              </div>

              <p className="mt-3 rounded-card bg-paper p-4 text-[14px] leading-[1.65] text-ink-3">{r.body}</p>

              {r.ownerReply && (
                <div className="mt-3 rounded-card border-l-2 border-orange bg-paper p-4">
                  <div className="label">Owner reply</div>
                  <p className="mt-2 text-[13px] leading-relaxed text-ink-3">{r.ownerReply}</p>
                </div>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                {(['published', 'hidden'] as const)
                  .filter((s) => s !== r.status)
                  .map((s) => (
                    <form key={s} action={setReviewStatusAction}>
                      <input type="hidden" name="reviewId" value={r.id} />
                      <input type="hidden" name="status" value={s} />
                      <button className={s === 'hidden'
                        ? 'btn border border-rule text-[#B4441F]'
                        : 'btn-primary'}>
                        {s === 'hidden' ? 'Hide it' : 'Publish it'}
                      </button>
                    </form>
                  ))}
              </div>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}

import Link from 'next/link';
import { desc, eq, and, sql } from 'drizzle-orm';
import { db, posts, cities, states, users } from '@/db';
import { requireStaff } from '@/lib/auth';
import { togglePostStatus, deletePost } from './actions';

export const dynamic = 'force-dynamic';

const SECTIONS = [
  ['things-to-do', 'Things to do'], ['food', 'Food'],
  ['how-to-reach', 'How to reach'], ['nearby', 'Near by'],
] as const;

type Search = { status?: string; section?: string; saved?: string };

export default async function PostsPage({ searchParams }: { searchParams: Promise<Search> }) {
  await requireStaff();
  const sp = await searchParams;

  const conds = [];
  if (sp.status === 'draft' || sp.status === 'published') conds.push(eq(posts.status, sp.status));
  if (sp.section) conds.push(eq(posts.section, sp.section as 'food'));

  const rows = await db
    .select({
      id: posts.id, title: posts.title, slug: posts.slug, section: posts.section,
      status: posts.status, featured: posts.featured, updatedAt: posts.updatedAt,
      city: cities.slug, cityName: cities.name, state: states.slug, author: users.name,
    })
    .from(posts)
    .leftJoin(cities, eq(posts.cityId, cities.id))
    .leftJoin(states, eq(cities.stateId, states.id))
    .leftJoin(users, eq(posts.authorId, users.id))
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(desc(posts.updatedAt))
    .limit(200);

  const [counts] = await db.select({
    all: sql<number>`count(*)::int`,
    drafts: sql<number>`count(*) filter (where status = 'draft')::int`,
    live: sql<number>`count(*) filter (where status = 'published')::int`,
  }).from(posts);

  const chip = (label: string, href: string, on: boolean, n?: number) => (
    <Link key={href} href={href} className={`pill ${on ? 'pill-on' : 'pill-off'}`}>
      {label}{n !== undefined && <span className="font-medium opacity-60">{n}</span>}
    </Link>
  );

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">Posts</h1>
        </div>
        <Link href="/admin/posts/new" className="btn-primary">New post</Link>
      </div>

      {sp.saved && (
        <p className="mt-5 rounded-card border border-trust bg-trust-soft px-4 py-3 text-[13px] font-medium text-trust-ink">
          Saved.
        </p>
      )}

      <div className="rail mt-7 flex gap-2 overflow-x-auto pb-1">
        {chip('All', '/admin/posts', !sp.status && !sp.section, counts?.all ?? 0)}
        {chip('Live', '/admin/posts?status=published', sp.status === 'published', counts?.live ?? 0)}
        {chip('Drafts', '/admin/posts?status=draft', sp.status === 'draft', counts?.drafts ?? 0)}
        <span className="mx-1 w-px shrink-0 bg-rule" />
        {SECTIONS.map(([slug, label]) => chip(label, `/admin/posts?section=${slug}`, sp.section === slug))}
      </div>

      {rows.length === 0 ? (
        <div className="card-flat mt-7 p-10 text-center">
          <h2 className="m-0 font-serif text-[26px] leading-tight">Nothing here yet</h2>
          <p className="mx-auto mt-3 max-w-[46ch] text-[15px] leading-relaxed text-muted-2">
            Until a city has published posts, its pages fall back to generated scaffolding and stay out of search results.
          </p>
          <Link href="/admin/posts/new" className="btn-primary mt-6">Write the first one</Link>
        </div>
      ) : (
        <div className="hair mt-7 [grid-template-columns:1fr]">
          {rows.map((p) => (
            <div key={p.id} className="flex flex-wrap items-center justify-between gap-x-5 gap-y-3 bg-white px-5 py-4">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2.5">
                  <Link href={`/admin/posts/${p.id}`} className="font-serif text-[19px] leading-tight text-ink hover:text-orange">
                    {p.title}
                  </Link>
                  {p.featured && <span className="label text-orange">Featured</span>}
                </div>
                <div className="meta mt-1.5">
                  {p.cityName} · {SECTIONS.find(([s]) => s === p.section)?.[1] ?? p.section}
                  {p.author && ` · ${p.author}`}
                  {p.updatedAt && ` · ${new Date(p.updatedAt).toLocaleDateString('en-GB')}`}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${
                  p.status === 'published' ? 'bg-trust text-white' : 'bg-sand text-orange-deep'
                }`}>{p.status}</span>

                {p.status === 'published' && p.state && (
                  <a href={`/${p.state}/${p.city}/${p.section}/${p.slug}`} target="_blank" rel="noopener noreferrer"
                    className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink-2">View</a>
                )}

                <form action={togglePostStatus}>
                  <input type="hidden" name="id" value={p.id} />
                  <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink">
                    {p.status === 'published' ? 'Unpublish' : 'Publish'}
                  </button>
                </form>

                <form action={deletePost}>
                  <input type="hidden" name="id" value={p.id} />
                  <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-[#B4441F]">
                    Delete
                  </button>
                </form>
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  );
}

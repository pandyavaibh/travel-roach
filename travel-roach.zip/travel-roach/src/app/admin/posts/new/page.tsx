import { asc, eq } from 'drizzle-orm';
import { db, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import PostForm from '../PostForm';

export const dynamic = 'force-dynamic';

export default async function NewPostPage() {
  await requireStaff();

  const cityOptions = await db
    .select({ id: cities.id, name: cities.name, state: states.name, published: cities.published })
    .from(cities)
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(states.name), asc(cities.name));

  return <PostForm cities={cityOptions} />;
}

'use client';

import Link from 'next/link';
import { useActionState, useState } from 'react';
import Editor from '@/components/admin/Editor';
import { savePost, type PostState } from './actions';
import { slugify } from '@/lib/slug';

const initial: PostState = {};

const SECTIONS = [
  ['things-to-do', 'Things to do'], ['food', 'Food'],
  ['how-to-reach', 'How to reach'], ['nearby', 'Near by'],
] as const;

type CityOption = { id: number; name: string; state: string; published: boolean | null };

type Post = {
  id: number; cityId: number | null; section: string; kicker: string | null;
  title: string; slug: string; dek: string | null; bodyHtml: string | null;
  takeaways: string[] | null; readingMinutes: number | null;
  featured: boolean | null; status: string | null;
};

const field = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';

export default function PostForm({ cities, post }: { cities: CityOption[]; post?: Post }) {
  const [state, action, pending] = useActionState(savePost, initial);
  const [title, setTitle] = useState(post?.title ?? '');
  const [slug, setSlug] = useState(post?.slug ?? '');

  // Slug follows the title until someone edits it by hand.
  const [slugTouched, setSlugTouched] = useState(!!post);
  const shownSlug = slugTouched ? slug : slugify(title);

  return (
    <form action={action} className="p-[clamp(20px,3vw,40px)]">
      {post && <input type="hidden" name="id" value={post.id} />}

      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <div className="eyebrow">{post ? 'Editing' : 'New post'}</div>
          <h1 className="m-0 mt-3 font-serif text-[clamp(26px,3.4vw,40px)] leading-none tracking-[-.025em]">
            {post ? 'Edit post' : 'Write a post'}
          </h1>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Link href="/admin/posts" className="btn-outline">Cancel</Link>
          <button name="intent" value="draft" disabled={pending} className="btn-outline disabled:opacity-60">
            Save draft
          </button>
          <button name="intent" value="published" disabled={pending} className="btn-primary disabled:opacity-60">
            {pending ? 'Saving…' : 'Publish'}
          </button>
        </div>
      </div>

      {state.error && (
        <p className="mt-5 rounded-card border border-[#E7C9BC] bg-[#FDF0EA] px-4 py-3 text-[13px] font-medium text-[#B4441F]">
          {state.error}
        </p>
      )}

      <div className="mt-8 grid items-start gap-[clamp(20px,2.6vw,36px)] [grid-template-columns:repeat(auto-fit,minmax(300px,1fr))]">
        <div className="min-w-0 lg:[grid-column:span_2]">
          <label className="label mb-2 block">Title</label>
          <input name="title" value={title} onChange={(e) => setTitle(e.target.value)}
            placeholder="The 7am heritage walk through Ahmedabad" className={field + ' text-base'} />

          <label className="label mb-2 mt-5 block">Standfirst</label>
          <textarea name="dek" rows={2} defaultValue={post?.dek ?? ''}
            placeholder="One sentence on what the reader gets. Shown on cards and in search results."
            className={field + ' resize-y'} />

          <label className="label mb-2 mt-5 block">Body</label>
          <Editor name="bodyHtml" defaultValue={post?.bodyHtml ?? ''} />

          <label className="label mb-2 mt-5 block">Before you go</label>
          <textarea name="takeaways" rows={4} defaultValue={(post?.takeaways ?? []).join('\n')}
            placeholder={'One per line.\nGo early — the first two hours are the difference.\nCarry cash for entry fees.'}
            className={field + ' resize-y'} />
          <p className="mt-2 text-[12px] text-muted-2">One per line. Rendered as the sand-coloured box at the end of the article.</p>
        </div>

        <aside className="flex min-w-0 flex-col gap-5 lg:sticky lg:top-6">
          <div className="card-flat p-5">
            <label className="label mb-2 block">City</label>
            <select name="cityId" defaultValue={post?.cityId ?? ''} className={field}>
              <option value="">Choose a city…</option>
              {cities.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} — {c.state}{c.published ? '' : ' (hidden)'}
                </option>
              ))}
            </select>

            <label className="label mb-2 mt-4 block">Section</label>
            <select name="section" defaultValue={post?.section ?? 'things-to-do'} className={field}>
              {SECTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>

            <label className="label mb-2 mt-4 block">Kicker</label>
            <input name="kicker" defaultValue={post?.kicker ?? ''} placeholder="Heritage walk" className={field} />
            <p className="mt-2 text-[12px] text-muted-2">The small orange label above the title. Doubles as the section filter.</p>
          </div>

          <div className="card-flat p-5">
            <label className="label mb-2 block">URL</label>
            <input name="slug" value={shownSlug}
              onChange={(e) => { setSlugTouched(true); setSlug(e.target.value); }}
              placeholder="auto-generated-from-title" className={field + ' font-mono text-[12px]'} />
            <p className="mt-2 break-all text-[12px] text-muted-2">/{'{state}'}/{'{city}'}/{'{section}'}/{shownSlug || '…'}</p>

            <label className="label mb-2 mt-4 block">Reading time</label>
            <input name="readingMinutes" type="number" min={1} max={90} defaultValue={post?.readingMinutes ?? ''}
              placeholder="Auto" className={field} />
            <p className="mt-2 text-[12px] text-muted-2">Left blank, it is counted from the body.</p>

            <label className="mt-4 flex min-h-[44px] cursor-pointer items-center gap-3 text-sm text-ink-2">
              <input type="checkbox" name="featured" defaultChecked={!!post?.featured}
                className="h-[16px] w-[16px] shrink-0 appearance-none rounded border border-rule-3 bg-white checked:bg-trust" />
              Feature at the top of the section
            </label>
          </div>
        </aside>
      </div>
    </form>
  );
}

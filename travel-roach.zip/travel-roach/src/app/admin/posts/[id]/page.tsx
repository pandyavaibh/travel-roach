import { notFound } from 'next/navigation';
import { asc, eq } from 'drizzle-orm';
import { db, posts, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import PostForm from '../PostForm';

export const dynamic = 'force-dynamic';

export default async function EditPostPage({ params }: { params: Promise<{ id: string }> }) {
  await requireStaff();
  const { id } = await params;

  const [post] = await db.select().from(posts).where(eq(posts.id, Number(id))).limit(1);
  if (!post) notFound();

  const cityOptions = await db
    .select({ id: cities.id, name: cities.name, state: states.name, published: cities.published })
    .from(cities)
    .innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(states.name), asc(cities.name));

  return <PostForm cities={cityOptions} post={post} />;
}

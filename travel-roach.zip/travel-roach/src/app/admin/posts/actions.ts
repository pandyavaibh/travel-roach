'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { and, eq, ne } from 'drizzle-orm';
import { db, posts, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { slugify } from '@/lib/slug';

export type PostState = { error?: string; ok?: string };

const SECTIONS = ['things-to-do', 'food', 'how-to-reach', 'nearby'] as const;

const schema = z.object({
  id: z.coerce.number().int().positive().optional(),
  cityId: z.coerce.number().int().positive({ message: 'Choose a city' }),
  section: z.enum(SECTIONS),
  kicker: z.string().trim().max(80).optional().or(z.literal('')),
  title: z.string().trim().min(4, 'Give it a title').max(255),
  slug: z.string().trim().max(200).optional().or(z.literal('')),
  dek: z.string().trim().max(500).optional().or(z.literal('')),
  bodyHtml: z.string().max(200_000).optional().or(z.literal('')),
  takeaways: z.string().max(4000).optional().or(z.literal('')),
  readingMinutes: z.coerce.number().int().min(1).max(90).optional(),
  featured: z.union([z.literal('on'), z.literal('')]).optional(),
  intent: z.enum(['draft', 'published']),
});

/** Words per minute is a blunt instrument, but better than asking the writer. */
function readingTime(html: string): number {
  const words = html.replace(/<[^>]+>/g, ' ').split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(words / 220));
}

async function uniqueSlug(base: string, excludeId?: number): Promise<string> {
  let slug = base;
  for (let n = 2; n < 50; n++) {
    const clash = await db.select({ id: posts.id }).from(posts)
      .where(excludeId ? and(eq(posts.slug, slug), ne(posts.id, excludeId)) : eq(posts.slug, slug))
      .limit(1);
    if (!clash.length) return slug;
    slug = `${base}-${n}`;
  }
  return `${base}-${Date.now()}`;
}

export async function savePost(_prev: PostState, fd: FormData): Promise<PostState> {
  const user = await requireStaff();
  const parsed = schema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  const d = parsed.data;
  const body = d.bodyHtml ?? '';
  const takeaways = (d.takeaways ?? '').split('\n').map((t) => t.trim()).filter(Boolean);

  const values = {
    cityId: d.cityId,
    section: d.section,
    kicker: d.kicker || null,
    title: d.title,
    dek: d.dek || null,
    bodyHtml: body || null,
    takeaways,
    readingMinutes: d.readingMinutes || readingTime(body),
    featured: d.featured === 'on',
    status: d.intent,
    authorId: user.id,
    // Set once, on first publish, so re-editing does not reorder the list.
    publishedAt: d.intent === 'published' ? new Date() : null,
  };

  if (d.id) {
    const [existing] = await db.select({ publishedAt: posts.publishedAt })
      .from(posts).where(eq(posts.id, d.id)).limit(1);
    if (!existing) return { error: 'That post no longer exists.' };

    await db.update(posts).set({
      ...values,
      slug: await uniqueSlug(slugify(d.slug || d.title), d.id),
      publishedAt: d.intent === 'published' ? (existing.publishedAt ?? new Date()) : null,
    }).where(eq(posts.id, d.id));
  } else {
    await db.insert(posts).values({
      ...values,
      slug: await uniqueSlug(slugify(d.slug || d.title)),
    });
  }

  revalidatePath('/admin/posts');
  await revalidatePublicCity(d.cityId);
  redirect('/admin/posts?saved=1');
}

export async function deletePost(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('id'));
  const [row] = await db.select({ cityId: posts.cityId }).from(posts).where(eq(posts.id, id)).limit(1);
  await db.delete(posts).where(eq(posts.id, id));
  revalidatePath('/admin/posts');
  if (row?.cityId) await revalidatePublicCity(row.cityId);
}

export async function togglePostStatus(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('id'));
  const [row] = await db.select({ status: posts.status, publishedAt: posts.publishedAt, cityId: posts.cityId })
    .from(posts).where(eq(posts.id, id)).limit(1);
  if (!row) return;

  const next = row.status === 'published' ? 'draft' : 'published';
  await db.update(posts).set({
    status: next,
    publishedAt: next === 'published' ? (row.publishedAt ?? new Date()) : null,
  }).where(eq(posts.id, id));

  revalidatePath('/admin/posts');
  if (row.cityId) await revalidatePublicCity(row.cityId);
}

/* ---------------- Cities ---------------- */

/** Publishing a city takes it off file-backed scaffolding and onto real content. */
export async function toggleCityPublished(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('id'));
  const [row] = await db.select({ published: cities.published }).from(cities).where(eq(cities.id, id)).limit(1);
  if (!row) return;
  await db.update(cities).set({ published: !row.published }).where(eq(cities.id, id));
  revalidatePath('/admin/cities');
  await revalidatePublicCity(id);
}

/** The per-city search-engine switch. */
export async function toggleCityNoindex(fd: FormData) {
  await requireStaff();
  const id = Number(fd.get('id'));
  const [row] = await db.select({ noindex: cities.noindex }).from(cities).where(eq(cities.id, id)).limit(1);
  if (!row) return;
  await db.update(cities).set({ noindex: !row.noindex }).where(eq(cities.id, id));
  revalidatePath('/admin/cities');
  await revalidatePublicCity(id);
}

/** Clears the cache for every public route belonging to one city. */
async function revalidatePublicCity(cityId: number) {
  const [row] = await db
    .select({ city: cities.slug, state: states.slug })
    .from(cities)
    .innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(cities.id, cityId))
    .limit(1);
  if (!row) return;

  const base = `/${row.state}/${row.city}`;
  revalidatePath(base);
  revalidatePath(`/${row.state}`);
  for (const s of SECTIONS) revalidatePath(`${base}/${s}`, 'page');
  revalidatePath(`${base}/[section]/[slug]`, 'page');
}

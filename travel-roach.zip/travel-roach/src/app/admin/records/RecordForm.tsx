'use client';

import Link from 'next/link';
import { useActionState, useState } from 'react';
import Editor from '@/components/admin/Editor';
import { saveRecord, type RecordState } from './actions';
import { slugify } from '@/lib/slug';
import type { RecordDef, Field } from '@/lib/records';

const initial: RecordState = {};

const base = 'w-full rounded-card border border-rule bg-paper px-4 py-3 text-sm outline-none focus:border-orange';
const WIDTH: Record<string, string> = {
  full: 'col-span-full', half: 'col-span-full sm:col-span-3', third: 'col-span-full sm:col-span-2',
};

type CityOption = { id: number; name: string; state: string };
type Day = { title: string; detail: string };

export default function RecordForm({ def, cityOptions, record }: {
  def: RecordDef;
  cityOptions: CityOption[];
  record?: Record<string, unknown> | null;
}) {
  const [state, action, pending] = useActionState(saveRecord, initial);

  const val = (n: string) => {
    const v = record?.[n];
    if (v === null || v === undefined) return '';
    if (Array.isArray(v)) return v.join('\n');
    return String(v);
  };

  const [name, setName] = useState(val(def.titleField));
  const [slug, setSlug] = useState(val('slug'));
  const [rich, setRich] = useState(val('historyHtml'));
  const [days, setDays] = useState<Day[]>(() => {
    const plan = record?.dayPlan;
    if (Array.isArray(plan) && plan.length) {
      return (plan as { title?: string; detail?: string }[]).map((d) => ({ title: d.title ?? '', detail: d.detail ?? '' }));
    }
    return [{ title: '', detail: '' }];
  });

  const renderField = (fl: Field) => {
    // City and name get bespoke handling; everything else is generic.
    if (fl.name === 'cityId') {
      return (
        <select name="cityId" defaultValue={val('cityId')} className={base} aria-label="City" required>
          <option value="">Choose a city…</option>
          {cityOptions.map((c) => (
            <option key={c.id} value={c.id}>{c.name} — {c.state}</option>
          ))}
        </select>
      );
    }
    if (fl.name === def.titleField) {
      return (
        <input name={fl.name} value={name} required maxLength={fl.max}
          onChange={(e) => setName(e.target.value)} className={base} aria-label={fl.label} />
      );
    }
    if (fl.name === 'slug') {
      return (
        <div className="flex gap-2">
          <input name="slug" value={slug} onChange={(e) => setSlug(e.target.value)}
            placeholder={slugify(name) || 'auto'} className={base} aria-label="URL slug" />
          <button type="button" onClick={() => setSlug(slugify(name))}
            className="btn-outline whitespace-nowrap px-4">Rebuild</button>
        </div>
      );
    }

    switch (fl.type) {
      case 'rich':
        return (
          <>
            <Editor value={rich} onChange={setRich} />
            <input type="hidden" name={fl.name} value={rich} />
          </>
        );
      case 'textarea':
        return <textarea name={fl.name} defaultValue={val(fl.name)} rows={4} maxLength={fl.max}
          className={base + ' resize-y'} aria-label={fl.label} />;
      case 'lines':
        return <textarea name={fl.name} defaultValue={val(fl.name)} rows={4}
          className={base + ' resize-y'} aria-label={fl.label} />;
      case 'number':
        return <input name={fl.name} type="number" defaultValue={val(fl.name)}
          className={base} aria-label={fl.label} />;
      case 'date':
        return <input name={fl.name} type="date" defaultValue={val(fl.name)}
          className={base} aria-label={fl.label} />;
      case 'checkbox':
        return (
          <label className="flex min-h-[44px] cursor-pointer items-center gap-2.5 text-sm text-ink-2">
            <input type="checkbox" name={fl.name} defaultChecked={val(fl.name) === 'true'}
              className="h-[15px] w-[15px] shrink-0 appearance-none rounded-[3px] border border-rule-3 bg-white checked:bg-trust" />
            {fl.label}
          </label>
        );
      case 'dayplan':
        return (
          <div className="flex flex-col gap-2.5">
            {days.map((d, i) => (
              <div key={i} className="rounded-card border border-rule bg-white p-4">
                <div className="flex items-center justify-between gap-3">
                  <span className="label">Day {i + 1}</span>
                  {days.length > 1 && (
                    <button type="button" onClick={() => setDays(days.filter((_, k) => k !== i))}
                      className="text-[11px] font-semibold text-[#B4441F]">Remove</button>
                  )}
                </div>
                <input name="dayTitle" value={d.title} placeholder="What happens that day"
                  onChange={(e) => setDays(days.map((x, k) => k === i ? { ...x, title: e.target.value } : x))}
                  className={base + ' mt-3'} aria-label={`Day ${i + 1} title`} />
                <textarea name="dayDetail" value={d.detail} rows={2} placeholder="The detail"
                  onChange={(e) => setDays(days.map((x, k) => k === i ? { ...x, detail: e.target.value } : x))}
                  className={base + ' mt-2 resize-y'} aria-label={`Day ${i + 1} detail`} />
              </div>
            ))}
            <button type="button" onClick={() => setDays([...days, { title: '', detail: '' }])}
              className="btn-outline self-start">Add a day</button>
          </div>
        );
      default:
        return <input name={fl.name} defaultValue={val(fl.name)} maxLength={fl.max}
          className={base} aria-label={fl.label} />;
    }
  };

  const published = val('status') === 'published';

  return (
    <form action={action}>
      <input type="hidden" name="kind" value={def.kind} />
      {record?.id ? <input type="hidden" name="id" value={String(record.id)} /> : null}

      <div className="grid grid-cols-6 gap-x-4 gap-y-5">
        {def.fields.map((fl) => (
          <div key={fl.name} className={WIDTH[fl.width ?? 'full']}>
            {fl.type !== 'checkbox' && (
              <label className="label mb-2 block">
                {fl.label}{fl.required && <span className="text-orange"> *</span>}
              </label>
            )}
            {renderField(fl)}
            {fl.hint && <p className="mt-1.5 text-[11px] text-muted">{fl.hint}</p>}
          </div>
        ))}
      </div>

      {state.error && <p className="mt-5 text-[13px] text-[#B4441F]">{state.error}</p>}

      <div className="sticky bottom-0 mt-7 flex flex-wrap items-center gap-2 border-t border-rule bg-paper/95 py-4 backdrop-blur">
        <button name="intent" value="published" disabled={pending} className="btn-primary disabled:opacity-60">
          {pending ? 'Saving…' : published ? 'Update' : 'Publish'}
        </button>
        <button name="intent" value="draft" disabled={pending} className="btn-outline disabled:opacity-60">
          Save as draft
        </button>
        <span className="flex-1" />
        <Link href={`/admin/records/${def.kind}`} className="text-[13px] font-semibold text-muted-2 hover:text-orange">
          Cancel
        </Link>
      </div>
    </form>
  );
}

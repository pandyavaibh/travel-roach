'use server';

import { z } from 'zod';
import { redirect } from 'next/navigation';
import { revalidatePath } from 'next/cache';
import { and, eq, ne } from 'drizzle-orm';
import { db, attractions, events, packages, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { slugify } from '@/lib/slug';
import { RECORDS, type RecordKind } from '@/lib/records';

export type RecordState = { error?: string; ok?: string };

const TABLES = { attractions, events, itineraries: packages } as const;

const str = (fd: FormData, k: string) => {
  const v = fd.get(k);
  return typeof v === 'string' && v.trim() !== '' ? v.trim() : null;
};
const num = (fd: FormData, k: string) => {
  const v = str(fd, k);
  if (v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
};
const lines = (fd: FormData, k: string) =>
  (str(fd, k) ?? '').split('\n').map((s) => s.trim()).filter(Boolean);

async function uniqueSlug(kind: RecordKind, base: string, excludeId?: number) {
  const table = TABLES[kind];
  let slug = base;
  for (let n = 2; n < 60; n++) {
    const [clash] = await db.select({ id: table.id }).from(table)
      .where(excludeId ? and(eq(table.slug, slug), ne(table.id, excludeId)) : eq(table.slug, slug))
      .limit(1);
    if (!clash) return slug;
    slug = `${base}-${n}`;
  }
  return `${base}-${Date.now()}`;
}

/** Day plans arrive as three parallel arrays from the repeatable fieldset. */
function readDayPlan(fd: FormData) {
  const titles = fd.getAll('dayTitle').map(String);
  const details = fd.getAll('dayDetail').map(String);
  return titles
    .map((title, i) => ({ day: i + 1, title: title.trim(), detail: (details[i] ?? '').trim() }))
    .filter((d) => d.title || d.detail);
}

export async function saveRecord(_prev: RecordState, fd: FormData): Promise<RecordState> {
  await requireStaff();

  const kind = String(fd.get('kind') ?? '') as RecordKind;
  const def = RECORDS[kind];
  if (!def) return { error: 'Unknown record type.' };

  const id = num(fd, 'id');
  const cityId = num(fd, 'cityId');
  const name = str(fd, 'name');
  const intent = String(fd.get('intent') ?? 'draft') === 'published' ? 'published' : 'draft';

  if (!cityId) return { error: 'Choose a city.' };
  if (!name || name.length < 3) return { error: 'Give it a name.' };

  const slug = await uniqueSlug(kind, slugify(str(fd, 'slug') || name), id ?? undefined);
  const table = TABLES[kind];

  let values: Record<string, unknown>;

  if (kind === 'attractions') {
    values = {
      cityId, name, slug, status: intent,
      category: str(fd, 'category'),
      summary: str(fd, 'summary'),
      historyHtml: str(fd, 'historyHtml'),
      tips: lines(fd, 'tips'),
      timings: str(fd, 'timings'),
      entryFee: str(fd, 'entryFee'),
      timeNeeded: str(fd, 'timeNeeded'),
      bestTime: str(fd, 'bestTime'),
      closedOn: str(fd, 'closedOn'),
      photography: str(fd, 'photography'),
      nearestStation: str(fd, 'nearestStation'),
      accessibility: str(fd, 'accessibility'),
      lat: str(fd, 'lat'),
      lng: str(fd, 'lng'),
      sortRank: num(fd, 'sortRank') ?? 99,
    };
  } else if (kind === 'events') {
    const startsOn = str(fd, 'startsOn');
    if (!startsOn) return { error: 'A festival needs a start date.' };
    const endsOn = str(fd, 'endsOn');
    if (endsOn && endsOn < startsOn) return { error: 'The end date is before the start date.' };
    values = {
      cityId, name, slug, status: intent, startsOn, endsOn,
      venue: str(fd, 'venue'),
      season: str(fd, 'season'),
      ticketed: fd.get('ticketed') === 'on',
      priceFrom: str(fd, 'priceFrom'),
      bookAhead: str(fd, 'bookAhead'),
      note: str(fd, 'note'),
    };
  } else {
    const days = num(fd, 'days');
    if (!days || days < 1) return { error: 'How many days?' };
    values = {
      cityId, name, slug, status: intent, days,
      route: str(fd, 'route'),
      note: str(fd, 'note'),
      inclusions: lines(fd, 'inclusions'),
      dayPlan: readDayPlan(fd),
      priceFrom: num(fd, 'priceFrom'),
      sortOrder: num(fd, 'sortOrder') ?? 0,
    };
  }

  if (id) {
    const [existing] = await db.select({ id: table.id }).from(table).where(eq(table.id, id)).limit(1);
    if (!existing) return { error: 'That record no longer exists.' };
    await db.update(table).set(values as never).where(eq(table.id, id));
  } else {
    await db.insert(table).values(values as never);
  }

  revalidatePath(`/admin/records/${kind}`);
  await revalidateCity(cityId);
  redirect(`/admin/records/${kind}?saved=1`);
}

export async function deleteRecord(fd: FormData) {
  await requireStaff();
  const kind = String(fd.get('kind') ?? '') as RecordKind;
  const table = TABLES[kind];
  if (!table) return;
  const id = Number(fd.get('id'));

  const [row] = await db.select({ cityId: table.cityId }).from(table).where(eq(table.id, id)).limit(1);
  await db.delete(table).where(eq(table.id, id));

  revalidatePath(`/admin/records/${kind}`);
  if (row?.cityId) await revalidateCity(row.cityId);
}

export async function toggleRecordStatus(fd: FormData) {
  await requireStaff();
  const kind = String(fd.get('kind') ?? '') as RecordKind;
  const table = TABLES[kind];
  if (!table) return;
  const id = Number(fd.get('id'));

  const [row] = await db.select({ status: table.status, cityId: table.cityId })
    .from(table).where(eq(table.id, id)).limit(1);
  if (!row) return;

  await db.update(table)
    .set({ status: row.status === 'published' ? 'draft' : 'published' } as never)
    .where(eq(table.id, id));

  revalidatePath(`/admin/records/${kind}`);
  if (row.cityId) await revalidateCity(row.cityId);
}

async function revalidateCity(cityId: number) {
  const [row] = await db
    .select({ city: cities.slug, state: states.slug })
    .from(cities).innerJoin(states, eq(cities.stateId, states.id))
    .where(eq(cities.id, cityId)).limit(1);
  if (!row) return;

  const base = `/${row.state}/${row.city}`;
  revalidatePath(base);
  revalidatePath(`/${row.state}`);
  for (const seg of ['attractions', 'festivals', 'itineraries']) revalidatePath(`${base}/${seg}`, 'page');
  revalidatePath(`${base}/[section]/[slug]`, 'page');
}

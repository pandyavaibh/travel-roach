import Link from 'next/link';
import { notFound } from 'next/navigation';
import type { Metadata } from 'next';
import { asc, desc, eq } from 'drizzle-orm';
import { db, attractions, events, packages, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { RECORDS, isRecordKind } from '@/lib/records';
import { deleteRecord, toggleRecordStatus } from '../actions';

export const dynamic = 'force-dynamic';

type Props = {
  params: Promise<{ kind: string }>;
  searchParams: Promise<{ saved?: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { kind } = await params;
  return { title: isRecordKind(kind) ? RECORDS[kind].label : 'Records' };
}

export default async function RecordListPage({ params, searchParams }: Props) {
  await requireStaff();
  const { kind } = await params;
  const { saved } = await searchParams;
  if (!isRecordKind(kind)) notFound();

  const def = RECORDS[kind];

  const rows = kind === 'attractions'
    ? await db.select({
        id: attractions.id, name: attractions.name, slug: attractions.slug,
        status: attractions.status, extra: attractions.category,
        order: attractions.sortRank, city: cities.name, state: states.slug, citySlug: cities.slug,
      }).from(attractions)
        .innerJoin(cities, eq(attractions.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .orderBy(cities.name, asc(attractions.sortRank)).limit(300)
    : kind === 'events'
    ? await db.select({
        id: events.id, name: events.name, slug: events.slug,
        status: events.status, extra: events.startsOn,
        order: events.id, city: cities.name, state: states.slug, citySlug: cities.slug,
      }).from(events)
        .innerJoin(cities, eq(events.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .orderBy(asc(events.startsOn)).limit(300)
    : await db.select({
        id: packages.id, name: packages.name, slug: packages.slug,
        status: packages.status, extra: packages.days,
        order: packages.sortOrder, city: cities.name, state: states.slug, citySlug: cities.slug,
      }).from(packages)
        .innerJoin(cities, eq(packages.cityId, cities.id))
        .innerJoin(states, eq(cities.stateId, states.id))
        .orderBy(cities.name, asc(packages.days)).limit(300);

  const extraLabel = kind === 'attractions' ? 'Category' : kind === 'events' ? 'Starts' : 'Days';

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="m-0 mt-3 font-serif text-[clamp(30px,4vw,48px)] leading-none tracking-[-.025em]">{def.label}</h1>
        </div>
        <Link href={`/admin/records/${kind}/new`} className="btn-primary">New {def.singular.toLowerCase()}</Link>
      </div>

      {saved && (
        <p className="mt-5 rounded-card border border-sand-rule bg-sand px-4 py-3 text-[13px] text-ink-3">Saved.</p>
      )}

      <div className="rail mt-6 flex gap-2 overflow-x-auto">
        {Object.values(RECORDS).map((r) => (
          <Link key={r.kind} href={`/admin/records/${r.kind}`}
            className={`pill ${r.kind === kind ? 'pill-on' : 'pill-off'}`}>{r.label}</Link>
        ))}
      </div>

      {rows.length === 0 ? (
        <div className="card-flat mt-6 p-8 text-center">
          <p className="m-0 text-[15px] text-muted-2">
            Nothing here yet. Until you add some, the public site falls back to generated scaffolding.
          </p>
          <Link href={`/admin/records/${kind}/new`} className="btn-primary mt-4">Add the first one</Link>
        </div>
      ) : (
        <>
          <div className="label mt-7 border-b border-rule pb-3">{rows.length} total</div>
          <div className="hair mt-px [grid-template-columns:1fr]">
            {rows.map((r) => (
              <div key={r.id} className="flex flex-wrap items-center justify-between gap-x-5 gap-y-3 bg-white px-5 py-4">
                <div className="min-w-0">
                  <Link href={`/admin/records/${kind}/${r.id}`}
                    className="font-serif text-[19px] leading-tight text-ink hover:text-orange">{r.name}</Link>
                  <div className="meta mt-1.5">
                    {r.city} · {extraLabel}: {String(r.extra ?? '—')}
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`inline-block rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[.08em] ${r.status === 'published' ? 'bg-trust text-white' : 'bg-sand text-orange-deep'}`}>
                    {r.status}
                  </span>
                  {r.status === 'published' && (
                    <a href={`/${r.state}/${r.citySlug}/${def.segment}/${r.slug}`} target="_blank" rel="noopener noreferrer"
                      className="text-[12px] font-semibold text-muted-2 hover:text-orange">View</a>
                  )}
                  <form action={toggleRecordStatus}>
                    <input type="hidden" name="kind" value={kind} />
                    <input type="hidden" name="id" value={r.id} />
                    <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-ink">
                      {r.status === 'published' ? 'Unpublish' : 'Publish'}
                    </button>
                  </form>
                  <form action={deleteRecord}>
                    <input type="hidden" name="kind" value={kind} />
                    <input type="hidden" name="id" value={r.id} />
                    <button className="inline-flex min-h-[38px] items-center rounded-full border border-rule px-3.5 text-[12px] font-semibold text-[#B4441F]">
                      Delete
                    </button>
                  </form>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </main>
  );
}

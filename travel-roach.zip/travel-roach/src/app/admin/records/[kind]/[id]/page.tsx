import { notFound } from 'next/navigation';
import { asc, eq } from 'drizzle-orm';
import { db, attractions, events, packages, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { RECORDS, isRecordKind } from '@/lib/records';
import RecordForm from '../../RecordForm';

export const dynamic = 'force-dynamic';

export default async function EditRecordPage({ params }: { params: Promise<{ kind: string; id: string }> }) {
  await requireStaff();
  const { kind, id } = await params;
  if (!isRecordKind(kind)) notFound();

  const def = RECORDS[kind];
  const table = kind === 'attractions' ? attractions : kind === 'events' ? events : packages;

  const [record] = await db.select().from(table).where(eq(table.id, Number(id))).limit(1);
  if (!record) notFound();

  const cityOptions = await db
    .select({ id: cities.id, name: cities.name, state: states.name })
    .from(cities).innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(cities.name));

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">{def.label}</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(28px,3.6vw,42px)] leading-none tracking-[-.025em]">
        {(record as { name: string }).name}
      </h1>
      <div className="mt-7 max-w-[860px]">
        <RecordForm def={def} cityOptions={cityOptions} record={record as Record<string, unknown>} />
      </div>
    </main>
  );
}

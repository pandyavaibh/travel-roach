import { notFound } from 'next/navigation';
import { asc, eq } from 'drizzle-orm';
import { db, cities, states } from '@/db';
import { requireStaff } from '@/lib/auth';
import { RECORDS, isRecordKind } from '@/lib/records';
import RecordForm from '../../RecordForm';

export const dynamic = 'force-dynamic';

export default async function NewRecordPage({ params }: { params: Promise<{ kind: string }> }) {
  await requireStaff();
  const { kind } = await params;
  if (!isRecordKind(kind)) notFound();

  const def = RECORDS[kind];
  const cityOptions = await db
    .select({ id: cities.id, name: cities.name, state: states.name })
    .from(cities).innerJoin(states, eq(cities.stateId, states.id))
    .orderBy(asc(cities.name));

  return (
    <main className="p-[clamp(20px,3vw,40px)]">
      <div className="eyebrow">{def.label}</div>
      <h1 className="m-0 mt-3 font-serif text-[clamp(28px,3.6vw,42px)] leading-none tracking-[-.025em]">
        New {def.singular.toLowerCase()}
      </h1>
      <div className="mt-7 max-w-[860px]">
        <RecordForm def={def} cityOptions={cityOptions} />
      </div>
    </main>
  );
}

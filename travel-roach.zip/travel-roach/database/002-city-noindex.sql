-- Adds the per-city search-engine switch.
-- Run once against a database created before this column existed:
--   psql "$DATABASE_URL" -f database/002-city-noindex.sql

ALTER TABLE cities ADD COLUMN IF NOT EXISTS noindex BOOLEAN DEFAULT TRUE;

-- Ahmedabad has real content, so let it be indexed.
UPDATE cities SET noindex = FALSE WHERE slug = 'ahmedabad';
